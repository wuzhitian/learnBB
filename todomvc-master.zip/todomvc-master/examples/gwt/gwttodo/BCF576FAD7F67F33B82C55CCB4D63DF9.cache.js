(function(){var $gwt_version = "2.6.0";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $strongName = 'BCF576FAD7F67F33B82C55CCB4D63DF9';var $stats = $wnd.__gwtStatsEvent ? function(a) {return $wnd.__gwtStatsEvent(a);} : null;var $sessionId = $wnd.__gwtStatsSessionId ? $wnd.__gwtStatsSessionId : null;$stats && $stats({moduleName:'gwttodo',sessionId:$sessionId,subSystem:'startup',evtGroup:'moduleStartup',millis:(new Date()).getTime(),type:'moduleEvalStart'});function V(){}
function BE(){}
function ab(){}
function vc(){}
function Mc(){}
function Sc(){}
function he(){}
function He(){}
function Xe(){}
function ef(){}
function Zf(){}
function Pg(){}
function Gh(){}
function Vn(){}
function Yn(){}
function mq(){}
function pq(){}
function vr(){}
function ot(){}
function rt(){}
function nu(){}
function qu(){}
function Bu(){}
function Iv(){}
function Fw(){}
function Mx(){}
function Px(){}
function Sx(){}
function ny(){}
function qy(){}
function Yy(){}
function fD(){}
function pw(a){}
function Bs(a){Dr()}
function rr(){qr()}
function Yr(){Xr()}
function vb(){Kc()}
function Hs(){ts()}
function Ts(a){Ks=a}
function ze(a,b){a.i=b}
function Be(a,b){a.a=b}
function Ce(a,b){a.b=b}
function fx(a,b){a.b=b}
function ex(a,b){a.a=b}
function Fm(a,b){a.h=b}
function Gm(a,b){a.l=b}
function Hm(a,b){a.m=b}
function no(a,b){a.u=b}
function Qc(a,b){a.a+=b}
function Rc(a,b){a.a+=b}
function gd(b,a){b.id=a}
function jb(a){this.a=a}
function Bc(a){this.a=a}
function Ec(a){this.a=a}
function mf(a){this.a=a}
function Of(a){this.a=a}
function tg(a){this.a=a}
function Eg(a){this.a=a}
function Ug(a){this.a=a}
function gh(a){this.a=a}
function _n(a){this.a=a}
function rp(a){this.a=a}
function Bp(a){this.a=a}
function Dp(a){this.a=a}
function hq(a){this.a=a}
function Tq(a){this.a=a}
function ls(a){this.a=a}
function mw(a){this.a=a}
function wx(a){this.a=a}
function yx(a){this.a=a}
function Ax(a){this.a=a}
function Cx(a){this.a=a}
function ey(a){this.a=a}
function hy(a){this.a=a}
function Sy(a){this.a=a}
function jz(a){this.a=a}
function wz(a){this.a=a}
function iB(a){this.a=a}
function zB(a){this.a=a}
function _B(a){this.d=a}
function pv(a){this.c=a}
function vC(a){this.a=a}
function lD(a){this.b=a}
function wD(a){this.b=a}
function bf(){this.a={}}
function sg(){this.a=[]}
function lb(){this.a=mb()}
function Xt(){Xt=BE;au()}
function Mu(){Mu=BE;Uu()}
function je(){je=BE;le()}
function fb(){new KC}
function fc(){return bc}
function zg(a){return a.a}
function Ig(a){return a.a}
function Zg(a){return a.a}
function mh(a){return a.a}
function Fh(a){return a.a}
function th(){return null}
function Sg(){return null}
function qA(){oA(this)}
function eE(){PA(this)}
function fE(){PA(this)}
function ad(a){a.focus()}
function oA(a){a.a=new Sc}
function db(){db=BE;new fb}
function Au(){throw new zE}
function Qe(){this.c=++Ne}
function Ds(a){td(a);Es(a)}
function Cs(a){Dr();return}
function Ew(a){Lv(a.a,a.b)}
function Ln(a,b){Rn(a.a,b)}
function vx(a,b){ox(a.a,b)}
function ap(a,b){Iq(a.n,b)}
function St(a,b){Mt(a.b,b)}
function Yx(a,b){vv(b,a.n)}
function jd(c,a,b){c[a]=b}
function Cd(c,a,b){c[a]=b}
function af(a,b,c){a.a[b]=c}
function Nb(b,a){b.length=a}
function Py(){vb.call(this)}
function fz(){vb.call(this)}
function qz(){vb.call(this)}
function tz(){vb.call(this)}
function Jz(){vb.call(this)}
function uA(){vb.call(this)}
function zE(){vb.call(this)}
function If(){Jf.call(this)}
function Lf(){Jf.call(this)}
function Rf(){this.a=new If}
function pn(){this.a=new qA}
function lA(){this.a=new Sc}
function lE(){this.a=new fE}
function kE(){this.a=new eE}
function wb(a){this.e=a;Kc()}
function xb(a){this.e=a;Kc()}
function wc(a){return a.C()}
function Qd(){Od();return Jd}
function ig(){gg();return cg}
function fr(){dr();return _q}
function nr(){lr();return hr}
function Wu(){Uu();return Pu}
function Kx(){Ix();return Ex}
function xy(a){wy();this.a=a}
function By(a,b){lx(b.a,a.a)}
function Iy(a,b){mx(b.a,a.a)}
function ev(a,b){hv(a,b,a.c)}
function Wo(a,b){jp(a,a.c,b)}
function Bd(b,a){b.checked=a}
function kd(b,a){b.tabIndex=a}
function Ab(){Ab=BE;zb=new V}
function mc(){mc=BE;lc=new vc}
function rq(){rq=BE;lq=new pq}
function ry(){ry=BE;my=new qy}
function wy(){wy=BE;vy=new Rf}
function Og(){Og=BE;Ng=new Pg}
function qr(){qr=BE;pr=new Qe}
function Xr(){Xr=BE;Wr=new Qe}
function Dr(){Dr=BE;Br=new Hs}
function bD(){bD=BE;aD=new fD}
function WD(){this.a=new Date}
function cn(){return !!$stats}
function _e(a,b){return a.a[b]}
function lo(a){return Dr(),a.u}
function Xf(a){Uf.call(this,a)}
function Gp(a){mf.call(this,a)}
function Kg(a){wb.call(this,a)}
function Lg(a){yb.call(this,a)}
function zt(a){wt.call(this,a)}
function fh(){gh.call(this,{})}
function oz(a){wb.call(this,a)}
function rz(a){wb.call(this,a)}
function uz(a){wb.call(this,a)}
function Kz(a){wb.call(this,a)}
function Oz(a){oz.call(this,a)}
function vA(a){wb.call(this,a)}
function QD(a){BD.call(this,a)}
function SD(a){lD.call(this,a)}
function Rp(a){tc((mc(),lc),a)}
function Gq(a){uc((mc(),lc),a)}
function wh(a){throw new Kg(a)}
function qh(a){return new Ug(a)}
function sh(a){return new zh(a)}
function bn(a){return new _m[a]}
function Ww(a,b){return a.b==b}
function Gz(a,b){return a>b?a:b}
function Hz(a,b){return a<b?a:b}
function js(a,b){a.__listener=b}
function fd(b,a){b.className=a}
function Kb(b,a){b[b.length]=a}
function Lb(b,a){b[b.length]=a}
function Mb(b,a){b[b.length]=a}
function qp(a,b){$o(a.a,b,true)}
function bp(a,b,c){Jq(a.n,b,c)}
function zs(a,b,c){es(a);As(b,c)}
function mo(a,b){no(a,(Dr(),b))}
function wt(a){no(this,(Dr(),a))}
function wu(a){no(this,(Dr(),a))}
function Gr(a,b){Dr();xs(Br,a,b)}
function Hr(a,b){Dr();zs(Br,a,b)}
function lx(a,b){HC(a.d,b);qx(a)}
function qx(a){rx(a);sx(a);px(a)}
function nd(a){a=Zz(a);return a}
function td(a){a.preventDefault()}
function as(){wf.call(this,null)}
function su(){hu.call(this,lu())}
function Kt(){ab.call(this,db())}
function qw(a){this.c=a;pw(this)}
function eo(a){Yc(a.parentNode,a)}
function od(a){return a.keyCode|0}
function Ad(a){return !!a.checked}
function Sm(a){return a.l|a.m<<22}
function To(a,b){return uq(a.n,b)}
function Uo(a,b){return vq(a.n,b)}
function Wq(a,b){return EC(a.k,b)}
function _s(a,b){return gv(a.b,b)}
function Tv(a,b){return a.f.pb(b)}
function po(a,b){Gr((Dr(),a.u),b)}
function oo(a,b){so((Dr(),a.u),b)}
function yt(a,b){hd((Dr(),a.u),b)}
function wo(a,b){!!a.s&&vf(a.s,b)}
function iE(a,b){return QA(a.a,b)}
function kD(a,b){return a.b.ob(b)}
function TA(b,a){return b.e[gF+a]}
function qc(a){return !!a.a||!!a.f}
function Wc(a){return a.firstChild}
function Kw(a){a.a.K(a.d,a.c,a.b)}
function ee(a){ce();Mb(_d,a);fe()}
function ph(a){return Dg(),a?Cg:Bg}
function zq(a){return !a.e?a.i:a.e}
function Jr(a){return ds((Dr(),a))}
function Nr(a){Lr();!!Kr&&Os(Kr,a)}
function XC(a,b,c){a.splice(b,c)}
function Pd(a,b){Fd.call(this,a,b)}
function hg(a,b){Fd.call(this,a,b)}
function mr(a,b){Fd.call(this,a,b)}
function Vu(a,b){Fd.call(this,a,b)}
function Mv(){Nv.call(this,new KC)}
function Ay(){Ay=BE;wy();zy=new Qe}
function Hy(){Hy=BE;wy();Gy=new Qe}
function eA(){eA=BE;bA={};dA={}}
function YB(a){return a.b<a.d.wb()}
function Av(a,b){this.a=a;this.b=b}
function by(a,b){this.a=a;this.b=b}
function pC(a,b){this.a=a;this.b=b}
function uE(a,b){this.a=a;this.b=b}
function Fd(a,b){this.b=a;this.c=b}
function yw(a,b){this.b=a;this.a=b}
function hx(a,b){this.b=a;this.a=b}
function EB(a,b){this.b=a;this.a=b}
function bt(){this.b=new kv(this)}
function Ps(){this.a=new wf(null)}
function Mn(){this.a='localStorage'}
function lt(a){kt();Xf.call(this,a)}
function Cy(a){Ay();xy.call(this,a)}
function Jy(a){Hy();xy.call(this,a)}
function Iu(a){jd((Dr(),a.u),dG,cF)}
function et(a,b){Zs(a,b,(Dr(),a.u))}
function $w(a,b,c){Zw(a,Uh(b,39),c)}
function $o(a,b,c){Hq(a.n,b,c,true)}
function jA(a,b){Qc(a.a,b);return a}
function kA(a,b){Rc(a.a,b);return a}
function pA(a,b){Rc(a.a,b);return a}
function ud(a,b){a.textContent=b||cF}
function hd(b,a){b.innerHTML=a||cF}
function VA(b,a){return gF+a in b.e}
function hc(a,b){return Tc(a,b,null)}
function Zh(a){return a==null?null:a}
function Wz(b,a){return b.indexOf(a)}
function ZD(a){return a<10?yF+a:cF+a}
function _b(a){!!a&&(us(a),gs(a.a))}
function gx(a){hx.call(this,a,false)}
function Sd(){Pd.call(this,'NONE',0)}
function Ud(){Pd.call(this,'BLOCK',1)}
function av(){Vu.call(this,'LEFT',2)}
function KC(){this.a=Kh(mm,FE,0,0,0)}
function wf(a){this.a=new Lf;this.b=a}
function rA(a){oA(this);Rc(this.a,a)}
function vm(a){return wm(a.l,a.m,a.h)}
function up(a,b,c){return vo(a.a,b,c)}
function Th(a,b){return a.cM&&a.cM[b]}
function LB(a,b){(a<0||a>=b)&&QB(a,b)}
function ed(c,a,b){c.setAttribute(a,b)}
function cd(b,a){b.removeAttribute(a)}
function Zt(b,a){b.__gwt_resolve=$t(a)}
function ic(a){$wnd.clearTimeout(a)}
function dp(a){ep.call(this,new op(a))}
function Ju(a){wt.call(this,a);new Zf}
function cv(){Vu.call(this,'RIGHT',3)}
function Yu(){Vu.call(this,'CENTER',0)}
function Wd(){Pd.call(this,'INLINE',2)}
function YC(a,b,c,d){a.splice(b,c,d)}
function uc(a,b){a.c=xc(a.c,[b,false])}
function Vc(a,b){return a.childNodes[b]}
function Sh(a,b){return a.cM&&!!a.cM[b]}
function ec(a){return a.$H||(a.$H=++Xb)}
function Yh(a){return a.tM==BE||Sh(a,1)}
function Tz(b,a){return b.charCodeAt(a)}
function wm(a,b,c){return {l:a,m:b,h:c}}
function lu(){gu();return $doc.body}
function jE(a,b){return $A(a.a,b)!=null}
function on(a,b){pA(a.a,b.a);return a}
function Yw(a,b,c,d){Xw(a,b,Uh(c,39),d)}
function $u(){Vu.call(this,'JUSTIFY',1)}
function BD(a){lD.call(this,a);this.a=a}
function MD(a){wD.call(this,a);this.a=a}
function op(a){this.a=a;mo(this,this.a)}
function yb(a){this.e=!a?null:sb(a);Kc()}
function Jf(){this.d=new eE;this.c=false}
function kt(){kt=BE;it=new ot;jt=new rt}
function We(){We=BE;Ve=new Re(jF,new Xe)}
function Ge(){Ge=BE;Fe=new Re(iF,new He)}
function Np(){Mp=$E(function(a){Pp(a)})}
function Er(a,b){Dr();Uc(a,(Xt(),Yt(b)))}
function Wh(a,b){return a!=null&&Sh(a,b)}
function en(c,a,b){return a.replace(c,b)}
function Yc(b,a){return b.removeChild(a)}
function Uc(b,a){return b.appendChild(a)}
function Cq(a){return (!a.e?a.i:a.e).k.b}
function oB(a){return a.b=Uh(ZB(a.a),62)}
function Eb(a){return a==null?null:a.name}
function mb(){return (new Date).getTime()}
function Qn(a,b){return $wnd[a].getItem(b)}
function Bq(a,b){return Wq(!a.e?a.i:a.e,b)}
function Yz(c,a,b){return c.substr(a,b-a)}
function zd(b,a){return b.getElementById(a)}
function vd(a){return a.currentTarget||$wnd}
function EC(a,b){LB(b,a.b);return a.a[b]}
function Ff(a,b){var c;c=Gf(a,b);return c}
function Bf(a,b,c){var d;d=Ef(a,b);d.mb(c)}
function Yo(a){var b;b=Wp(a);!!b&&ad(b)}
function Zp(a){var b;b=Wp(a);!!b&&_c(b,PF)}
function Fz(){Fz=BE;Ez=Kh(lm,FE,53,256,0)}
function DC(a){a.a=Kh(mm,FE,0,0,0);a.b=0}
function tc(a,b){a.a=xc(a.a,[b,false]);rc(a)}
function xc(a,b){!a&&(a=[]);Kb(a,b);return a}
function az(a){var b=_m[a.b];a=null;return b}
function uC(a){var b;b=oB(a.a);return b.Fb()}
function BC(a,b){Mh(a.a,a.b++,b);return true}
function $b(a,b,c){return a.apply(b,c);var d}
function Zc(c,a,b){return c.replaceChild(a,b)}
function Xc(c,a,b){return c.insertBefore(a,b)}
function pd(a,b){return a.getAttribute(b)||cF}
function Db(a){return a==null?null:a.message}
function re(){return $doc.styleSheets.length}
function Mr(a){Lr();return Kr?Ls(Kr,a):null}
function uf(a,b,c){return new Of(Af(a.a,b,c))}
function Qf(a,b,c){return new Of(Af(a.a,b,c))}
function QB(a,b){throw new uz(fG+a+gG+b)}
function zf(a,b){!a.a&&(a.a=new KC);BC(a.a,b)}
function gf(a){var b;if(df){b=new ef;vf(a,b)}}
function Tr(){Or&&gf((!Pr&&(Pr=new as),Pr))}
function Ny(){wb.call(this,'divide by zero')}
function Yd(){Pd.call(this,'INLINE_BLOCK',3)}
function er(a,b,c){Fd.call(this,a,b);this.a=c}
function Jx(a,b,c){Fd.call(this,a,b);this.a=c}
function go(a,b,c){this.b=a;this.c=b;this.a=c}
function Nw(a,b,c){this.a=a;this.c=b;this.b=c}
function Qw(a,b,c){this.a=a;this.c=b;this.b=c}
function Xz(b,a){return b.substr(a,b.length-a)}
function bz(a){return typeof a=='number'&&a>0}
function kv(a){this.b=a;this.a=Kh(jm,FE,32,4,0)}
function le(){le=BE;je();ke=Kh(cm,FE,-1,30,1)}
function qq(){qq=BE;kq=new gn((Hn(),new En))}
function Ry(){Ry=BE;new Sy(false);new Sy(true)}
function Ph(){Ph=BE;Nh=[];Oh=[];Qh(new Gh,Nh,Oh)}
function ce(){ce=BE;_d=[];ae=[];be=[];Zd=new he}
function hA(){if(cA==256){bA=dA;dA={};cA=0}++cA}
function es(a){if(!cs){ws();new ls(a);cs=true}}
function zh(a){if(a==null){throw new Jz}this.a=a}
function $s(a,b){if(b<0||b>=a.b.c){throw new tz}}
function Rn(a,b){Qn(a,FF);$wnd[a].setItem(FF,b)}
function Ap(a,b){a.a.j=true;$p(a.a,b);a.a.j=false}
function zp(a,b,c,d){a.a.i=a.a.i||d;bq(a.a,b,c,d)}
function Qv(a){a.f.nb();a.i=a.g=0;a.j=true;Rv(a)}
function cq(a){dq.call(this,a,!Up&&(Up=new mq))}
function Uf(a){xb.call(this,Wf(a),Vf(a));this.a=a}
function Nt(a){this.a=a;this.b=_f(a);this.c=this.b}
function Qz(a){this.a='Unknown';this.c=a;this.b=-1}
function Xh(a){return a!=null&&a.tM!=BE&&!Sh(a,1)}
function Ms(a){return encodeURI(a).replace(WF,XF)}
function Qr(a){Sr();return Rr(df?df:(df=new Qe),a)}
function Jb(a){var b;return b=a,Yh(b)?b.hC():ec(b)}
function Mo(a){if(a.p){return a.p.U()}return false}
function _h(a){if(a!=null){throw new fz}return null}
function Rq(c){c.sort(function(a,b){return a-b})}
function JA(a){var b;b=new iB(a);return new pC(a,b)}
function hE(a,b){var c;c=WA(a.a,b,a);return c==null}
function Vv(a,b){Wv.call(this,a,b,null,0);wv(a,b.b)}
function of(a,b){var c;if(kf){c=new mf(b);vf(a.a,c)}}
function fe(){ce();if(!$d){$d=true;uc((mc(),lc),Zd)}}
function iu(a){gu();try{a.X()}finally{jE(fu,a)}}
function dD(a){bD();return a?new QD(a):new BD(null)}
function bd(b,a){return b[a]==null?null:String(b[a])}
function Km(a,b){return a.l==b.l&&a.m==b.m&&a.h==b.h}
function Lv(a,b){var c;c=a.a.f.wb();c>0&&yv(b,0,a.a)}
function Ib(a,b){var c;return c=a,Yh(c)?c.eQ(b):c===b}
function gn(a){this.b=0;this.c=0;this.a=26;this.d=a}
function Xq(a){this.k=new KC;this.n=new kE;this.f=a}
function jn(a){if(a==null){throw new Kz(zF)}this.a=a}
function rn(a){if(a==null){throw new Kz(zF)}this.a=a}
function zr(){zr=BE;xr=new vr;yr=new vr;wr=new vr}
function gu(){gu=BE;du=new nu;eu=new eE;fu=new kE}
function Dg(){Dg=BE;Bg=new Eg(false);Cg=new Eg(true)}
function Lr(){Lr=BE;Kr=new Ps;Ns(Kr)?null:(Kr=null)}
function oC(a){var b;b=new qB(a.b.a);return new vC(b)}
function Hw(a){var b;if(Dw){b=new Fw;!!a.s&&vf(a.s,b)}}
function yp(a){a.b&&(!Ip&&(Ip=new Sp),Rp(new Dp(a)))}
function Rr(a,b){return uf((!Pr&&(Pr=new as),Pr),a,b)}
function Ls(a,b){return uf(a.a,(!kf&&(kf=new Qe),kf),b)}
function uq(a,b){return up(a.j,b,(!Cv&&(Cv=new Qe),Cv))}
function vq(a,b){return up(a.j,b,(!Dw&&(Dw=new Qe),Dw))}
function dE(a,b){return Zh(a)===Zh(b)||a!=null&&Ib(a,b)}
function AE(a,b){return Zh(a)===Zh(b)||a!=null&&Ib(a,b)}
function Um(a,b){return {l:a.l^b.l,m:a.m^b.m,h:a.h^b.h}}
function Aq(a){return (lr(),jr)==a.d?-1:(!a.e?a.i:a.e).d}
function Yt(a){return a.__gwt_resolve?a.__gwt_resolve():a}
function PA(a){a.a=[];a.e={};a.c=false;a.b=null;a.d=0}
function Lw(a,b,c){this.a=a;this.d=b;this.c=null;this.b=c}
function hu(a){bt.call(this);no(this,(Dr(),a));xo(this)}
function Ut(){Vt.call(this,(Dr(),$doc.createElement(GF)))}
function vu(){wu.call(this,(Dr(),$doc.createElement(GF)))}
function gc(a){$wnd.setTimeout(function(){throw a},0)}
function jc(){return hc(function(){Wb!=0&&(Wb=0);Zb=-1},10)}
function vo(a,b,c){return uf(!a.s?(a.s=new wf(a)):a.s,c,b)}
function Eq(a){return (!a.e?a.i:a.e).j&&(!a.e?a.i:a.e).i==0}
function Rb(a){var b=Ob[a.charCodeAt(0)];return b==null?a:b}
function cD(a){bD();var b;b=new lE;hE(b,a);return new SD(b)}
function Kh(a,b,c,d,e){var f;f=Jh(e,d);Lh(a,b,c,f);return f}
function fp(a,b,c){Dr();js(b,a);hd(b,c.a);js(b,null);return b}
function Uh(a,b){if(a!=null&&!Th(a,b)){throw new fz}return a}
function ah(a,b){if(b==null){throw new Jz}return bh(a,b)}
function fv(a,b){if(b<0||b>=a.c){throw new tz}return a.a[b]}
function qe(a){if(re()==0){return ne(a)}return me(0,a,false)}
function Uz(a,b){if(!Wh(b,1)){return false}return String(a)==b}
function md(a){if($c(a)){return !!a&&a.nodeType==1}return false}
function ju(){gu();try{mt(fu,du)}finally{PA(fu.a);PA(eu)}}
function mx(a,b){fx(b,Zz(b.b));!b.b.length&&HC(a.d,b);qx(a)}
function Zx(a,b){Xx(a.g,(Ix(),Gx),b);Xx(a.f,Fx,b);Xx(a.i,Hx,b)}
function Mt(a,b){hd(a.a,b);if(a.c!=a.b){a.c=a.b;ag(a.a,a.b)}}
function _o(a,b){if(a.k){Kw(a.k.a);a.k=null}!!b&&(a.k=uq(a.n,b))}
function $B(a){if(a.c<0){throw new qz}a.d.ub(a.c);a.b=a.c;a.c=-1}
function Dq(a){return new yw((!a.e?a.i:a.e).g,(!a.e?a.i:a.e).f)}
function ov(a){if(!a.a){throw new qz}a.c.b.gb(a.a);--a.b;a.a=null}
function hs(a){var b=a.__listener;return !Xh(b)&&Wh(b,24)?b:null}
function sb(a){var b,c;b=a.cZ.c;c=a.A();return c!=null?b+_E+c:b}
function jv(a,b){var c;c=gv(a,b);if(c==-1){throw new zE}iv(a,c)}
function Nv(a){this.b=new kE;this.e=new eE;this.a=new Vv(this,a)}
function Hn(){Hn=BE;new RegExp('%5B',BF);new RegExp('%5D',BF)}
function Xx(a,b,c){b==c?_c((Dr(),a.u),lG):dd((Dr(),a.u),lG)}
function IC(a,b,c){var d;d=(LB(b,a.b),a.a[b]);Mh(a.a,b,c);return d}
function $y(a,b,c){var d;d=new Yy;d.c=a+b;bz(c)&&cz(c,d);return d}
function Lh(a,b,c,d){Ph();Rh(d,Nh,Oh);d.cZ=a;d.cM=b;d.qI=c;return d}
function Dv(a,b,c,d,e){this.f=a;this.b=b;this.a=c;this.d=d;this.e=e}
function Cb(a){Ab();vb.call(this);this.a=cF;this.b=a;this.a=cF;Jc()}
function Ft(){bt.call(this);no(this,(Dr(),$doc.createElement(GF)))}
function _t(){throw 'A PotentialElement cannot be resolved twice.'}
function $c(b){try{return !!b&&!!b.nodeType}catch(a){return false}}
function Jp(a,b){return iE(a.b,b.tagName.toLowerCase())||wd(b)>=0}
function Is(a,b){for(var c in a){a.hasOwnProperty(c)&&b(c,a[c])}}
function eh(d,a,b){if(b){var c=b.L();d.a[a]=c(b)}else{delete d.a[a]}}
function Zs(a,b,c){zo(b);ev(a.b,b);Dr();Uc(c,(Xt(),Yt(b.u)));Ao(b,a)}
function xs(a,b,c){es(a);ys(b,c);Uz('dragover',c)&&ys(b,'dragenter')}
function Tt(a,b){var c;a.c=b;c=(Lr(),Kr?Ms(b):b);jd(a.a,'href',WF+c)}
function Ih(a,b){var c,d;c=a;d=Jh(0,b);Lh(c.cZ,c.cM,c.qI,d);return d}
function YA(a,b){var c;c=a.b;a.b=b;if(!a.c){a.c=true;++a.d}return c}
function aB(a){var b;b=a.b;a.b=null;if(a.c){a.c=false;--a.d}return b}
function ne(a){var b;b=$doc.createStyleSheet();b.cssText=a;return b}
function Vh(a){if(a!=null&&(a.tM==BE||Sh(a,1))){throw new fz}return a}
function $t(a){return function(){this.__gwt_resolve=_t;return a.R()}}
function $h(a){return ~~Math.max(Math.min(a,2147483647),-2147483648)}
function $(a){if(!a.e){return}a.g=a.f;a.e=false;a.f=false;a.g&&It(a)}
function sm(a){if(Wh(a,57)){return a}return a==null?new Cb(null):qm(a)}
function ZB(a){if(a.b>=a.d.wb()){throw new zE}return a.d.pb(a.c=a.b++)}
function yd(a){!a.gwt_uid&&(a.gwt_uid=1);return 'gwt-uid-'+a.gwt_uid++}
function cc(a,b,c){var d;d=ac();try{return $b(a,b,c)}finally{dc(d)}}
function _w(a,b,c){var d;d=new pn;Zw(a,c,d);hd(b,(new rn(d.a.a.a)).a)}
function AC(a,b,c){(b<0||b>a.b)&&QB(b,a.b);YC(a.a,b,0,c);++a.b}
function GC(a,b){var c;c=(LB(b,a.b),a.a[b]);XC(a.a,b,1);--a.b;return c}
function Gs(a){var b;b=vd(a);while(!!b&&!hs(b)){b=b.parentNode}return b}
function pe(a){var b;b=re();if(b==0){return ne(a)}return me(b-1,a,true)}
function FC(a,b,c){for(;c<a.b;++c){if(AE(b,a.a[c])){return c}}return -1}
function Hh(a,b){var c,d;c=a;d=c.slice(0,b);Lh(c.cZ,c.cM,c.qI,d);return d}
function rd(a){var b=a.parentNode;(!b||b.nodeType!=1)&&(b=null);return b}
function xq(a){!a.e&&(a.e=new Zq(a.i));a.f=new Tq(a);Gq(a.f);return a.e}
function bo(a){var b,c;co();b=rd(a);c=qd(a);Uc(ao,a);return new go(b,c,a)}
function Fs(a){var b;b=vd(a);jd(b,'__gwtLastUnhandledEvent',a.type);Es(a)}
function wd(a){return a.tabIndex<65535?a.tabIndex:-(a.tabIndex%65535)-1}
function RA(a,b){return b==null?a.b:Wh(b,1)?TA(a,Uh(b,1)):SA(a,b,~~Jb(b))}
function QA(a,b){return b==null?a.c:Wh(b,1)?VA(a,Uh(b,1)):UA(a,b,~~Jb(b))}
function Wx(a,b){b?Cd(a.style,KF,(Od(),HF)):Cd(a.style,KF,(Od(),'block'))}
function Bo(a,b){a.r==-1?Hr((Dr(),a.u),b|(a.u.__eventBits||0)):(a.r|=b)}
function qg(d,a,b){if(b){var c=b.L();b=c(b)}else{b=undefined}d.a[a]=b}
function Rh(a,b,c){Ph();for(var d=0,e=b.length;d<e;++d){a[b[d]]=c[d]}}
function Qh(a,b,c){var d=0,e;for(var f in a){if(e=a[f]){b[d]=f;c[d]=e;++d}}}
function dc(a){a&&oc((mc(),lc));--Wb;if(a){if(Zb!=-1){ic(Zb);Zb=-1}}}
function co(){if(!ao){ao=$doc.createElement(GF);so(ao,false);Uc(lu(),ao)}}
function cp(a,b){if(!a){return}b?Cd(a.style,KF,cF):Cd(a.style,KF,(Od(),HF))}
function ZC(a,b,c,d){Array.prototype.splice.apply(a,[b,c].concat(d))}
function Vw(a,b,c){var d;d=Wc(b.firstChild);fx(c,d.value);sf(a.c,new Jy(c))}
function $A(a,b){return b==null?aB(a):Wh(b,1)?bB(a,Uh(b,1)):_A(a,b,~~Jb(b))}
function Es(a){var b;b=Gs(a);if(!b){return}Fr(a,b.nodeType!=1?null:b,hs(b))}
function Vf(a){var b;b=a.hb();if(!b.jb()){return null}return Uh(b.kb(),57)}
function Ur(){var a;if(Or){a=new Yr;!!Pr&&vf(Pr,a);return null}return null}
function gv(a,b){var c;for(c=0;c<a.c;++c){if(a.a[c]==b){return c}}return -1}
function HC(a,b){var c;c=FC(a,b,0);if(c==-1){return false}GC(a,c);return true}
function sd(a){var b=a.button;if(b==1){return 4}else if(b==2){return 2}return 1}
function dh(a,b,c){var d;if(b==null){throw new Jz}d=ah(a,b);eh(a,b,c);return d}
function nv(a){if(a.b>=a.c.c){throw new zE}a.a=a.c.a[a.b];++a.b;return a.a}
function ZA(e,a,b){var c,d=e.e;a=gF+a;a in d?(c=d[a]):++e.d;d[a]=b;return c}
function bB(d,a){var b,c=d.e;a=gF+a;if(a in c){b=c[a];--d.d;delete c[a]}return b}
function _y(a,b,c,d){var e;e=new Yy;e.c=a+b;bz(c)&&cz(c,e);e.a=d?8:0;return e}
function Wv(a,b,c,d){this.n=a;this.d=new mw(this);this.f=b;this.b=c;this.k=d}
function Qt(a){bt.call(this);mo(this,$doc.createElement(GF));hd((Dr(),this.u),a)}
function Tw(){var a;Mu();Nu.call(this,(a=$doc.createElement(hG),a.type='text',a))}
function Pn(){this.a=$wnd.localStorage!=null;$wnd.sessionStorage!=null}
function $z(a,b,c){a=a.slice(b,c);return String.fromCharCode.apply(null,a)}
function zc(b,c){mc();hc(function(){var a=$E(wc)(b);a&&hc(arguments.callee,c)},c)}
function bc(b){return function(){try{return cc(b,this,arguments)}catch(a){throw a}}}
function bu(b){Xt();try{return !!b&&!!b.__gwt_resolve}catch(a){return false}}
function Nn(){if((!Kn&&(Kn=new Pn),Kn).a){!Jn&&(Jn=new Mn);return Jn}return null}
function qd(a){var b=a.nextSibling;while(b&&b.nodeType!=1)b=b.nextSibling;return b}
function Tc(a,b,c){var d=$wnd.setTimeout(function(){a();c!=null&&_b(c)},b);return d}
function Fv(a,b,c,d,e,f){var g;g=new Dv(b,c,d,e,f);!!Cv&&!!a.s&&vf(a.s,g);return g}
function WA(a,b,c){return b==null?YA(a,c):Wh(b,1)?ZA(a,Uh(b,1),c):XA(a,b,c,~~Jb(b))}
function Zo(a,b,c){if(c){kd(b,a.o)}else{kd(b,-1);cd(b,'tabIndex');cd(b,'accessKey')}}
function xv(a,b,c){var d,e;for(e=oC(JA(a.b.a));YB(e.a.a);){d=Uh(uC(e),34);yv(d,b,c)}}
function ox(a,b){var c,d;for(d=new _B(a.d);d.b<d.d.wb();){c=Uh(ZB(d),39);c.a=b}qx(a)}
function eC(a,b){var c;this.a=a;_B.call(this,a);c=a.wb();(b<0||b>c)&&QB(b,c);this.b=b}
function oc(a){var b,c;if(a.c){c=null;do{b=a.c;a.c=null;c=yc(b,c)}while(a.c);a.c=c}}
function nc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=yc(b,c)}while(a.b);a.b=c}}
function pg(d,a){var b=d.a[a];var c=(oh(),nh)[typeof b];return c?c(b):xh(typeof b)}
function ys(a,b){var c=ps;var d=c[b]||c['_default_'];a.addEventListener(b,d,false)}
function Xo(a,b,c){var d;d=fp(a,(!So&&(So=$doc.createElement(GF)),So),c);kp(a.c,d,b)}
function Fr(a,b,c){Dr();var d;d=Ar;Ar=a;b==Cr&&ds(a.type)==8192&&(Cr=null);c.W(a);Ar=d}
function Zy(a,b,c){var d;d=new Yy;d.c=a+b;bz(c!=0?-c:0)&&cz(c!=0?-c:0,d);d.a=4;return d}
function kx(a){var b,c;c=new _B(a.d);while(c.b<c.d.wb()){b=Uh(ZB(c),39);b.a&&$B(c)}qx(a)}
function pc(a){var b;if(a.a){b=a.a;a.a=null;!a.f&&(a.f=[]);yc(b,a.f)}!!a.f&&(a.f=sc(a.f))}
function Az(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function um(a){var b,c,d;b=a&4194303;c=a>>22&4194303;d=a<0?1048575:0;return wm(b,c,d)}
function ft(a){Cd(a.style,'left',cF);Cd(a.style,'top',cF);Cd(a.style,'position',cF)}
function so(a,b){a.style.display=b?cF:HF;b?a.removeAttribute(IF):a.setAttribute(IF,JF)}
function Iq(a,b){if(!b){throw new Kz('KeyboardSelectionPolicy cannot be null')}a.d=b}
function Vz(b,a){if(a==null)return false;return b==a||b.toLowerCase()==a.toLowerCase()}
function _g(e,a){var b=e.a;var c=0;for(var d in b){b.hasOwnProperty(d)&&(a[c++]=d)}return a}
function Wp(a){var b;b=Aq(a.n);if(b>=0&&a.c.childNodes.length>b){return Vc(a.c,b)}return null}
function Xp(a,b){Fq(a.n,null);Vo(a,b);if(a.c.childNodes.length>b){return Vc(a.c,b)}return null}
function Pv(a,b){var c;c=a.f.mb(b);a.i=Hz(a.i,a.f.wb()-1);a.g=a.f.wb();a.j=true;Rv(a);return c}
function Et(a,b){var c;$s(a,b);c=a.a;a.a=fv(a.b,b);if(a.a!=c){!Ct&&(Ct=new Kt);Jt(Ct,c,a.a)}}
function xA(a,b){var c;while(a.jb()){c=a.kb();if(b==null?c==null:Ib(b,c)){return a}}return null}
function qB(a){var b;this.c=a;b=new KC;a.c&&BC(b,new zB(a));OA(a,b);NA(a,b);this.a=new _B(b)}
function Nq(a,b){this.c=(dr(),ar);this.d=(lr(),kr);this.a=a;this.j=b;this.i=new Xq(25)}
function Jq(a,b,c){if(b==(!a.e?a.i:a.e).i&&c==(!a.e?a.i:a.e).j){return}xq(a).i=b;xq(a).j=c;Mq(a)}
function rc(a){if(!a.i){a.i=true;!a.e&&(a.e=new Bc(a));zc(a.e,1);!a.g&&(a.g=new Ec(a));zc(a.g,50)}}
function Vo(a,b){if(!(b>=0&&b<Cq(a.n))){throw new uz('Row index: '+b+', Row size: '+zq(a.n).i)}}
function Qb(){Qb=BE;Ob=Ub();Pb=typeof JSON=='object'&&typeof JSON.parse==eF}
function oh(){oh=BE;nh={'boolean':ph,number:qh,string:sh,object:rh,'function':rh,undefined:th}}
function Od(){Od=BE;Nd=new Sd;Kd=new Ud;Ld=new Wd;Md=new Yd;Jd=Lh(dm,FE,3,[Nd,Kd,Ld,Md])}
function Uu(){Uu=BE;Qu=new Yu;Ru=new $u;Su=new av;Tu=new cv;Pu=Lh(im,FE,31,[Qu,Ru,Su,Tu])}
function Zm(){Zm=BE;Vm=wm(4194303,4194303,524287);Wm=wm(0,0,524288);Xm=Mm(1);Mm(2);Ym=Mm(0)}
function us(){var c=Is;c(captureEvents,function(a,b){$wnd.removeEventListener(a,b,true)})}
function wv(a,b){var c,d;a.c=b;a.d=true;for(d=oC(JA(a.b.a));YB(d.a.a);){c=Uh(uC(d),34);c.ab(b,true)}}
function CC(a,b){var c,d;c=b.yb();d=c.length;if(d==0){return false}ZC(a.a,a.b,0,c);a.b+=d;return true}
function Dm(a){var b,c;c=zz(a.h);if(c==32){b=zz(a.m);return b==32?zz(a.l)+32:b+20-10}else{return c-12}}
function rm(a){var b;if(Wh(a,2)){b=Uh(a,2);if(b.b!==(Ab(),zb)){return b.b===zb?null:b.b}}return a}
function qm(b){var c=b.__gwt$exception;if(!c){c=new Cb(b);try{b.__gwt$exception=c}catch(a){}}return c}
function rw(a,b){var c;this.c=a;pw(this);c=a.f.wb();if(b<0||b>c){throw new uz(fG+b+gG+c)}this.a=b}
function sf(b,c){var d;try{Cf(b.a,c)}catch(a){a=sm(a);if(Wh(a,38)){d=a;throw new Xf(d.a)}else throw rm(a)}}
function jx(a){var b,c;b=Zz(bd(lo(a.e.j),dG));if(Uz(b,cF))return;c=new gx(b);Iu(a.e.j);BC(a.d,c);qx(a)}
function jp(a,b,c){Mo(a)||(Dr(),js(a.u,a));hd(b,(!Ip&&(Ip=new Sp),c).a);Mo(a)||(Dr(),js(a.u,null))}
function Nu(a){Ju.call(this,a,(!Xn&&(Xn=new Yn),!Un&&(Un=new Vn)));fd((Dr(),this.u),'gwt-TextBox')}
function ax(){hb.call(this,Lh(om,FE,1,[iF,jF,MF,VF]));this.b=null;this.a=false;this.c=(wy(),wy(),vy)}
function Os(a,b){b=b==null?cF:b;if(!Uz(b,Ks==null?cF:Ks)){Ks=b;$wnd.location.hash=a.eb(b);of(a,b)}}
function rx(a){var b,c;Qv(a.b.a);for(c=new _B(a.d);c.b<c.d.wb();){b=Uh(ZB(c),39);a.c.a.Bb(b)&&Pv(a.b.a,b)}}
function sx(a){var b,c,d,e;e=a.d.b;b=0;for(d=new _B(a.d);d.b<d.d.wb();){c=Uh(ZB(d),39);c.a&&++b}$x(a.e,e,b)}
function Hf(a){var b,c;if(a.a){try{for(c=new _B(a.a);c.b<c.d.wb();){b=Uh(ZB(c),37);b.D()}}finally{a.a=null}}}
function uu(a,b){if(a.a!=b){return false}try{Ao(b,null)}finally{Yc((Dr(),a.u),b.u);a.a=null}return true}
function py(a){if(!a.a){a.a=true;ce();Mb(_d,'.GMY2FQLEI{display:inline;}');fe();return true}return false}
function _f(a){var b;b=bd(a,mF);if(Vz(nF,b)){return gg(),fg}else if(Vz(oF,b)){return gg(),eg}return gg(),dg}
function gA(a){eA();var b=gF+a;var c=dA[b];if(c!=null){return c}c=bA[b];c==null&&(c=fA(a));hA();return dA[b]=c}
function vs(a,b){var c=0,d=a.firstChild;while(d){if(d===b){return c}d.nodeType==1&&++c;d=d.nextSibling}return -1}
function zm(a,b,c,d,e){var f;f=Pm(a,b);c&&Cm(f);if(e){a=Bm(a,b);d?(tm=Nm(a)):(tm=wm(a.l,a.m,a.h))}return f}
function lf(a,b){var c;c=Uh(a.a,1);b.a.c=Uz(c,kF)?(Ix(),Fx):Uz(c,lF)?(Ix(),Hx):(Ix(),Gx);Zx(b.a.e,b.a.c);rx(b.a)}
function iv(a,b){var c;if(b<0||b>=a.c){throw new tz}--a.c;for(c=b;c<a.c;++c){Mh(a.a,c,a.a[c+1])}Mh(a.a,a.c,null)}
function pB(a){if(!a.b){throw new rz('Must call next() before remove().')}else{$B(a.a);$A(a.c,a.b.Fb());a.b=null}}
function xh(a){oh();throw new Kg("Unexpected typeof result '"+a+"'; please report this bug to the GWT team")}
function gg(){gg=BE;fg=new hg('RTL',0);eg=new hg('LTR',1);dg=new hg('DEFAULT',2);cg=Lh(em,FE,13,[fg,eg,dg])}
function gwtOnLoad(b,c,d,e){$moduleName=c;$moduleBase=d;if(b)try{$E(pm)()}catch(a){b(c)}else{$E(pm)()}}
function Jc(){var a,b,c,d;c=[];d=Kh(nm,FE,56,c.length,0);for(a=0,b=d.length;a<b;a++){d[a]=new Qz(c[a])}rb(d)}
function Kc(){var a,b,c,d;c=Ic(new Mc);d=Kh(nm,FE,56,c.length,0);for(a=0,b=d.length;a<b;a++){d[a]=new Qz(c[a])}rb(d)}
function rb(a){var b,c,d;c=Kh(nm,FE,56,a.length,0);for(d=0,b=a.length;d<b;++d){if(!a[d]){throw new Jz}c[d]=a[d]}}
function Ef(a,b){var c,d;d=Uh(RA(a.d,b),61);if(!d){d=new eE;WA(a.d,b,d)}c=Uh(d.b,60);if(!c){c=new KC;YA(d,c)}return c}
function Gf(a,b){var c,d;d=Uh(RA(a.d,b),61);if(!d){return bD(),bD(),aD}c=Uh(d.b,60);if(!c){return bD(),bD(),aD}return c}
function at(a,b){var c;if(b.t!=a){return false}try{Ao(b,null)}finally{c=(Dr(),b.u);Yc(rd(c),c);jv(a.b,b)}return true}
function ac(){var a;if(Wb!=0){a=mb();if(a-Yb>2000){Yb=a;Zb=jc()}}if(Wb++==0){nc((mc(),lc));return true}return false}
function hB(a,b){var c,d,e;if(Wh(b,62)){c=Uh(b,62);d=c.Fb();if(QA(a.a,d)){e=RA(a.a,d);return dE(c.Gb(),e)}}return false}
function Df(a,b,c){var d,e,f;d=Gf(a,b);e=d.vb(c);e&&d.rb()&&(f=Uh(RA(a.d,b),61),Uh(aB(f),60),f.d==0&&$A(a.d,b),undefined)}
function me(a,b,c){var d;d=$doc.styleSheets[a];c?(d.cssText+=b,undefined):(d.cssText=b+d.cssText,undefined);return d}
function _c(a,b){var c,d;b=nd(b);d=a.className;c=ld(d,b);if(c==-1){d.length>0?fd(a,d+hF+b):fd(a,b);return true}return false}
function Dz(a){var b,c;if(a>-129&&a<128){b=a+128;c=(Fz(),Ez)[b];!c&&(c=Ez[b]=new wz(a));return c}return new wz(a)}
function Nm(a){var b,c,d;b=~a.l+1&4194303;c=~a.m+(b==0?1:0)&4194303;d=~a.h+(b==0&&c==0?1:0)&1048575;return wm(b,c,d)}
function Cm(a){var b,c,d;b=~a.l+1&4194303;c=~a.m+(b==0?1:0)&4194303;d=~a.h+(b==0&&c==0?1:0)&1048575;Gm(a,b);Hm(a,c);Fm(a,d)}
function Rm(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return {l:c&4194303,m:d&4194303,h:e&1048575}}
function yo(a,b){var c;switch(Dr(),ds(b.type)){case 16:case 32:c=b.relatedTarget;if(!!c&&xd(a.u,c)){return}}De(b,a,a.u)}
function JC(a,b){var c;b.length<a.b&&(b=Ih(b,a.b));for(c=0;c<a.b;++c){Mh(b,c,a.a[c])}b.length>a.b&&Mh(b,a.b,null);return b}
function OA(e,a){var b=e.e;for(var c in b){if(c.charCodeAt(0)==58){var d=new EB(e,c.substring(1));a.mb(d)}}}
function ku(){gu();var a;a=Uh(RA(eu,null),29);if(a){return a}eu.d==0&&Qr(new qu);a=new su;WA(eu,null,a);hE(fu,a);return a}
function Wy(a){if(a>=48&&a<58){return a-48}if(a>=97&&a<97){return a-97+10}if(a>=65&&a<65){return a-65+10}return -1}
function ym(a,b){if(a.h==524288&&a.m==0&&a.l==0){b&&(tm=wm(0,0,0));return vm((Zm(),Xm))}b&&(tm=wm(a.l,a.m,a.h));return wm(0,0,0)}
function Vx(a,b){var c;c=a.o;Dr();zs(Br,c,1);js(c,new by(a,b));uo(a.j,new ey(b),(We(),We(),Ve));uo(a.a,new hy(b),(Ge(),Ge(),Fe))}
function aq(a){var b;b=Aq(a.n);if(b>=0&&b<zq(a.n).k.b){Wp(a);Vo(a,b);Bq(a.n,b);new jb(b+Dq(a.n).b,a.n);return false}return false}
function Mm(a){var b,c;if(a>-129&&a<128){b=a+128;Jm==null&&(Jm=Kh(fm,FE,18,256,0));c=Jm[b];!c&&(c=Jm[b]=um(a));return c}return um(a)}
function At(){var a;zt.call(this,(a=$doc.createElement(YF),a.setAttribute('type',RF),a));fd((Dr(),this.u),'gwt-Button')}
function Re(a,b){var c;Qe.call(this);this.a=b;!Ae&&(Ae=new bf);c=Uh(_e(Ae,a),60);if(!c){c=new KC;af(Ae,a,c)}c.mb(this);this.b=a}
function rg(a){var b,c,d;d=new lA;Rc(d.a,pF);for(c=0,b=a.a.length;c<b;c++){c>0&&(Rc(d.a,qF),d);jA(d,pg(a,c))}Rc(d.a,rF);return d.a.a}
function UA(h,a,b){var c=h.a[b];if(c){for(var d=0,e=c.length;d<e;++d){var f=c[d];var g=f.Fb();if(h.Eb(a,g)){return true}}}return false}
function NA(h,a){var b=h.a;for(var c in b){var d=parseInt(c,10);if(c==d){var e=b[d];for(var f=0,g=e.length;f<g;++f){a.mb(e[f])}}}}
function bh(f,a){var b=f.a;var c;a=String(a);b.hasOwnProperty(a)&&(c=b[a]);var d=(oh(),nh)[typeof c];var e=d?d(c):xh(typeof c);return e}
function fs(a,b,c,d){a.__gwt_disposeEvent=a.__gwt_disposeEvent||[];a.__gwt_disposeEvent.push({event:b,handler:c,capture:d})}
function ag(a,b){switch(b.c){case 0:{jd(a,mF,nF);break}case 1:{jd(a,mF,oF);break}case 2:{_f(a)!=(gg(),dg)&&jd(a,mF,cF);break}}}
function lr(){lr=BE;jr=new mr('DISABLED',0);kr=new mr('ENABLED',1);ir=new mr('BOUND_TO_SELECTION',2);hr=Lh(hm,FE,23,[jr,kr,ir])}
function Ix(){Ix=BE;Gx=new Jx('ALL',0,new Px);Fx=new Jx('ACTIVE',1,new Mx);Hx=new Jx('COMPLETED',2,new Sx);Ex=Lh(km,FE,40,[Gx,Fx,Hx])}
function Bn(){Bn=BE;new rn(cF);wn=new RegExp(AF,BF);xn=new RegExp(CF,BF);yn=new RegExp(DF,BF);An=new RegExp(EF,BF);zn=new RegExp(fF,BF)}
function Zz(c){if(c.length==0||c[0]>hF&&c[c.length-1]>hF){return c}var a=c.replace(/^(\s*)/,cF);var b=a.replace(/\s*$/,cF);return b}
function $p(a,b){var c;c=null;b==(zr(),xr)?(c=a.e):b==wr&&Eq(a.n)&&(c=a.d);!!c&&Et(a.f,_s(a.f,c));cp(a.c,!c);oo(a.f,!!c);wo(a,new rr)}
function bq(a,b,c,d){var e;if(!(b>=0&&b<zq(a.n).k.b)){return}e=Xp(a,b);(!c||a.i||d)&&ro(e,PF,c);Zo(a,e,c);if(c&&d&&!a.b){ad(e);Zp(a)}}
function vp(b,c,d){var e;try{e=new pn;_p(b.a,e,c,d);return new rn(e.a.a.a)}catch(a){a=sm(a);if(Wh(a,58)){return null}else throw rm(a)}}
function SA(h,a,b){var c=h.a[b];if(c){for(var d=0,e=c.length;d<e;++d){var f=c[d];var g=f.Fb();if(h.Eb(a,g)){return f.Gb()}}}return null}
function gs(a){var b,c,d,e;b=$doc.getElementsByTagName('*');for(d=0;d<b.length;d++){c=b[d];e=hs(c);if(e){es(a);As(c,0);js(c,null)}is(c)}}
function hb(a){var b,c,d,e;e=null;if(a!=null&&a.length>0){e=new kE;for(c=0,d=a.length;c<d;++c){b=a[c];hE(e,b)}}!!e&&(this.d=(bD(),new SD(e)))}
function sy(a){var b;b=new qA;Rc(b.a,"Clear completed (<span class='number-done' id='");pA(b,Cn(a));Rc(b.a,"'><\/span>)");return new jn(b.a.a)}
function uo(a,b,c){var d;d=Jr(c.b);d==-1?po(a,c.b):a.r==-1?Hr((Dr(),a.u),d|(a.u.__eventBits||0)):(a.r|=d);return uf(!a.s?(a.s=new wf(a)):a.s,c,b)}
function Mq(a){var b,c,d;d=(!a.e?a.i:a.e).g;b=Gz(0,Hz((!a.e?a.i:a.e).f,(!a.e?a.i:a.e).i-d));c=(!a.e?a.i:a.e).k.b-1;while(c>=b){GC(xq(a).k,c);--c}}
function dr(){dr=BE;br=new er('CURRENT_PAGE',0,true);ar=new er('CHANGE_PAGE',1,false);cr=new er('INCREASE_RANGE',2,false);_q=Lh(gm,FE,22,[br,ar,cr])}
function Rv(a){if(a.b){a.b.i=Hz(a.i+a.k,a.b.i);a.b.g=Gz(a.g+a.k,a.b.g);a.b.j=a.j||a.b.j;Rv(a.b);return}a.c=false;if(!a.e){a.e=true;uc((mc(),lc),a.d)}}
function $x(a,b,c){var d;d=b-c;Wx(a.c,b==0);Wx(a.k,b==0);Wx((Dr(),a.a.u),c==0);ud(a.d,cF+d);ud(a.e,d>1||d==0?'items':'item');hd(a.b,cF+c);Bd(a.o,b==c)}
function yv(a,b,c){var d,e,f,g,h,i,j,k,l;g=b+c.wb();h=a._();f=h.b;e=h.a;d=f+e;if(b==f||f<g&&d>b){k=f<b?b:f;i=d>g?g:d;j=i-k;l=c.xb(k-b,k-b+j);a.bb(k,l)}}
function Bm(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return wm(c,d,e)}
function Pp(a){var b,c,d,e;b=a.target;if(!md(b)){return}d=b;e=a.type;c=(Dr(),hs(d));while(!!d&&!c){d=rd(d);!!d&&Uz(JF,pd(d,QF+e))&&(c=hs(d))}!!c&&Fr(a,d,c)}
function Vp(a,b,c,d){var e,f;f=a.a.d;if(!!f&&kD(f,b.type)){e=Ww(a.a,Uh(d,39));Yw(a.a,c,d,b);a.b=Ww(a.a,Uh(d,39));e&&!a.b&&(!Ip&&(Ip=new Sp),Rp(new hq(a)))}}
function Jh(a,b){var c=new Array(b);if(a==3){for(var d=0;d<b;++d){c[d]={l:0,m:0,h:0}}}else if(a>0&&a<3){var e=a==1?0:false;for(var d=0;d<b;++d){c[d]=e}}return c}
function Uv(b,c){var d,e;try{e=b.f.ub(c);b.i=Hz(b.i,c);b.g=b.f.wb();b.j=true;Rv(b);return e}catch(a){a=sm(a);if(Wh(a,52)){d=a;throw new uz(d.e)}else throw rm(a)}}
function zo(a){if(!a.t){gu();iE(fu,a)&&iu(a)}else if(Wh(a.t,26)){Uh(a.t,26).gb(a)}else if(a.t){throw new rz("This widget's parent does not implement HasWidgets")}}
function bx(a){var b;b=new qA;Rc(b.a,"<div class='listItem editing'><input class='edit' value='");pA(b,Cn(a));Rc(b.a,"' type='text'><\/div>");return new jn(b.a.a)}
function cz(a,b){var c;b.b=a;if(a==2){c=String.prototype}else{if(a>0){var d=az(b);if(d){c=d.prototype}else{d=_m[a]=function(){};d.cZ=b;return}}else{return}}c.cZ=b}
function bE(){bE=BE;_D=Lh(om,FE,1,['Sun','Mon','Tue','Wed','Thu','Fri','Sat']);aE=Lh(om,FE,1,['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'])}
function Mz(){Mz=BE;Lz=Lh(bm,FE,-1,[48,49,50,51,52,53,54,55,56,57,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122])}
function yq(a,b,c){var d,e,f,g,h,i;if(b==null){return -1}e=-1;d=2147483647;i=a.k.b;for(h=0;h<i;h++){f=EC(a.k,h);if(Ib(b,f)){g=c-h<0?-(c-h):c-h;if(g<d){e=h;d=g}}}return e}
function is(a){var b=a.__gwt_disposeEvent;if(b){for(var c=0,d=b.length;c<d;c++){var e=b[c];a.removeEventListener(e.event,e.handler,e.capture);a.__gwt_disposeEvent=null}}}
function Bz(a){var b,c,d;b=Kh(bm,FE,-1,8,1);c=(Mz(),Lz);d=7;if(a>=0){while(a>15){b[d--]=c[a&15];a>>=4}}else{while(d>0){b[d--]=c[a&15];a>>=4}}b[d]=c[a&15];return $z(b,d,8)}
function Sv(a){var b;a.e&&(a.c=true);if(a.n.a!=a){return}b=a.f.wb();if(a.a!=b){a.a=b;wv(a.n,a.a)}if(a.j){xv(a.n,a.i,a.f.xb(a.i,a.g));a.j=false}a.i=2147483647;a.g=-2147483648}
function De(a,b,c){var d,e,f,g,h;if(Ae){h=Uh(_e(Ae,a.type),60);if(h){for(g=h.hb();g.jb();){f=Uh(g.kb(),6);d=f.a.a;e=f.a.b;Be(f.a,a);Ce(f.a,c);wo(b,f.a);Be(f.a,d);Ce(f.a,e)}}}}
function ws(){rs=$E(Es);ss=$E(Fs);var c=Is;var d=ps;c(d,function(a,b){d[a]=$E(b)});var e=qs;c(e,function(a,b){e[a]=$E(b)});c(e,function(a,b){$wnd.addEventListener(a,b,true)})}
function Im(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}Gm(a,c&4194303);Hm(a,d&4194303);Fm(a,e&1048575);return true}
function Lo(a,b){var c;if(a.p){throw new rz('Composite.initWidget() may only be called once.')}Wh(b,27)&&Uh(b,27);zo(b);c=(Dr(),b.u);no(a,c);bu(c)&&Zt((Xt(),c),a);a.p=b;Ao(b,a)}
function $n(a){if(!a.b){a.b=zd($doc,a.a);if(!a.b){throw new wb('Cannot find element with id "'+a.a+'". Perhaps it is not attached to the document body.')}cd(a.b,'id')}return a.b}
function yA(a){var b,c,d,e;d=new lA;b=null;Rc(d.a,pF);c=a.hb();while(c.jb()){b!=null?(Rc(d.a,b),d):(b=tF);e=c.kb();Rc(d.a,e===a?'(this Collection)':cF+e)}Rc(d.a,rF);return d.a.a}
function ld(a,b){var c,d,e;c=a.indexOf(b);while(c!=-1){if(c==0||a.charCodeAt(c-1)==32){d=c+b.length;e=a.length;if(d==e||d<e&&a.charCodeAt(d)==32){break}}c=a.indexOf(b,c+1)}return c}
function Op(a,b,c){var d;if(iE(a.a,c)){!Mp&&Np();d=(Dr(),b.u);if(!Uz(JF,pd(d,QF+c))){ed(d,QF+c,JF);d.addEventListener(c,Mp,true);fs(d,c,Mp,true)}return -1}else{return ds((Dr(),c))}}
function px(a){var b,c,d,e,f,g;d=Nn();if(d){f=new sg;for(b=0;b<a.d.b;b++){e=Uh(EC(a.d,b),39);c=new fh;dh(c,jG,new zh(e.b));dh(c,kG,(Dg(),e.a?Cg:Bg));g=pg(f,b);qg(f,b,c)}Ln(d,rg(f))}}
function _A(h,a,b){var c=h.a[b];if(c){for(var d=0,e=c.length;d<e;++d){var f=c[d];var g=f.Fb();if(h.Eb(a,g)){c.length==1?delete h.a[b]:c.splice(d,1);--h.d;return f.Gb()}}}return null}
function Lc(b){var c=cF;try{for(var d in b){if(d!='name'&&d!='message'&&d!='toString'){try{var e=d!='__gwt$exception'?b[d]:'<skipped>';c+='\n '+d+_E+e}catch(a){}}}}catch(a){}return c}
function Ao(a,b){var c;c=a.t;if(!b){try{!!c&&c.U()&&a.X()}finally{a.t=null}}else{if(c){throw new rz('Cannot set a new parent without first clearing the old parent')}a.t=b;b.U()&&a.V()}}
function wp(a,b,c){var d,e;e=vp(a,b,Dq(a.a.n).b);a.a.i=a.a.i||c;a.b=a.a.i;a.a.j=true;Wo(a.a,e);a.a.j=false;d=Wp(a.a);if(d){Zo(a.a,d,true);a.a.i&&Zp(a.a)}wo(a.a,new Gp(dD(zq(a.a.n).k)))}
function xp(a,b,c,d){var e,f;f=vp(a,b,Dq(a.a.n).b+c);a.a.i=a.a.i||d;a.b=a.a.i;a.a.j=true;Xo(a.a,c,f);a.a.j=false;e=Wp(a.a);if(e){Zo(a.a,e,true);a.a.i&&Zp(a.a)}wo(a.a,new Gp(dD(zq(a.a.n).k)))}
function Af(a,b,c){if(!b){throw new Kz('Cannot add a handler with a null type')}if(!c){throw new Kz('Cannot add a null handler')}a.b>0?zf(a,new Nw(a,b,c)):Bf(a,b,c);return new Lw(a,b,c)}
function dn(a){return $stats({moduleName:$moduleName,sessionId:$sessionId,subSystem:'startup',evtGroup:'moduleStartup',millis:(new Date).getTime(),type:'onModuleLoadStart',className:a})}
function vh(b){oh();var c;if(b==null){throw new Jz}if(b.length==0){throw new oz('empty argument')}try{return uh(b,true)}catch(a){a=sm(a);if(Wh(a,2)){c=a;throw new Lg(c)}else throw rm(a)}}
function mt(b,c){kt();var d,e,f,g;d=null;for(g=b.hb();g.jb();){f=Uh(g.kb(),32);try{c.ib(f)}catch(a){a=sm(a);if(Wh(a,57)){e=a;!d&&(d=new kE);hE(d,e)}else throw rm(a)}}if(d){throw new lt(d)}}
function Sb(b){Qb();var c=b.replace(/[\xad\u0600-\u0603\u06dd\u070f\u17b4\u17b5\u200b-\u200f\u2028-\u202e\u2060-\u2064\u206a-\u206f\ufeff\ufff9-\ufffb]/g,function(a){return Rb(a)});return c}
function yc(b,c){var d,e,f,g;for(e=0,f=b.length;e<f;e++){g=b[e];try{g[1]?g[0].C()&&(c=xc(c,g)):g[0].D()}catch(a){a=sm(a);if(Wh(a,57)){d=a;gc(Wh(d,2)?Uh(d,2).B():d)}else throw rm(a)}}return c}
function dd(a,b){var c,d,e,f,g;b=nd(b);g=a.className;e=ld(g,b);if(e!=-1){c=Zz(Yz(g,0,e));d=Zz(Xz(g,e+b.length));c.length==0?(f=d):d.length==0?(f=c):(f=c+hF+d);fd(a,f);return true}return false}
function vf(b,c){var d,e;!c.g||(c.g=false,c.i=null);e=c.i;ze(c,b.b);try{Cf(b.a,c)}catch(a){a=sm(a);if(Wh(a,38)){d=a;throw new Xf(d.a)}else throw rm(a)}finally{e==null?(c.g=true,c.i=null):(c.i=e)}}
function iC(a,b,c){this.c=a;this.a=b;this.b=c-b;if(b>c){throw new oz(qG+b+' > toIndex: '+c)}if(b<0){throw new uz(qG+b+' < 0')}if(c>a.wb()){throw new uz('toIndex: '+c+' > wrapped.size() '+a.wb())}}
function Bb(a){var b,c;if(a.c==null){b=a.b===zb?null:a.b;a.d=b==null?aF:Xh(b)?Eb(Vh(b)):Wh(b,1)?bF:(c=b,Yh(c)?c.cZ:ii).c;a.a=a.a+_E+(Xh(b)?Db(Vh(b)):b+cF);a.c=dF+a.d+') '+(Xh(b)?Lc(Vh(b)):cF)+a.a}}
function kp(a,b,c){var d,e,f,g,h;d=a.childNodes.length;h=null;c<d&&(h=a.childNodes[c]);e=b.childNodes.length;for(f=0;f<e;f++){if(!h){Uc(a,b.childNodes[0])}else{g=qd(h);Zc(a,b.childNodes[0],h);h=g}}}
function ep(a){var b;Lo(this,a);this.n=new Nq(this,new Bp(this));b=new kE;hE(b,LF);hE(b,MF);hE(b,NF);hE(b,jF);hE(b,iF);hE(b,OF);Kp((!Ip&&(Ip=new Sp),Ip),this,b);To(this,new Iv);_o(this,new rp(this))}
function sq(a,b,c){var d;d=new qA;Rc(d.a,'<div onclick="" __idx="');pA(d,Cn(cF+a));Rc(d.a,'" class="');pA(d,Cn(b));Rc(d.a,'" style="outline:none;" >');pA(d,c.a);Rc(d.a,'<\/div>');return new jn(d.a.a)}
function fA(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)))|0;c+=4}while(c<d){b=b*31+Tz(a,c++)}return b|0}
function Mh(a,b,c){if(c!=null){if(a.qI>0&&!Th(c,a.qI)){throw new Py}else if(a.qI==-1&&(c.tM==BE||Sh(c,1))){throw new Py}else if(a.qI<-1&&!(c.tM!=BE&&!Sh(c,1))&&!Th(c,-a.qI)){throw new Py}}return a[b]=c}
function Zq(a){var b,c;Xq.call(this,a.f);this.b=false;this.c=new KC;this.d=a.d;this.e=a.e;this.f=a.f;this.g=a.g;this.i=a.i;this.j=a.j;this.o=a.o;this.p=a.p;c=a.k.b;for(b=0;b<c;b++){BC(this.k,EC(a.k,b))}}
function XA(j,a,b,c){var d=j.a[c];if(d){for(var e=0,f=d.length;e<f;++e){var g=d[e];var h=g.Fb();if(j.Eb(a,h)){var i=g.Gb();g.Hb(b);return i}}}else{d=j.a[c]=[]}var g=new uE(a,b);d.push(g);++j.d;return null}
function _x(){this.n=new cq(new ax);Lo(this,jy(new ky(this)));ap(this.n,(lr(),jr));gd(this.c,'main');gd((Dr(),this.a.u),'clear-completed');gd(this.j.u,'new-todo');gd(this.k,'footer');gd(this.o,'toggle-all')}
function Tb(b){Qb();var c=b.replace(/[\x00-\x1f\xad\u0600-\u0603\u06dd\u070f\u17b4\u17b5\u200b-\u200f\u2028-\u202e\u2060-\u2064\u206a-\u206f\ufeff\ufff9-\ufffb"\\]/g,function(a){return Rb(a)});return fF+c+fF}
function Gc(a){var b,c,d;d=cF;a=Zz(a);b=a.indexOf(dF);c=a.indexOf(eF)==0?8:0;if(b==-1){b=Wz(a,String.fromCharCode(64));c=a.indexOf('function ')==0?9:0}b!=-1&&(d=Zz(Yz(a,c,b)));return d.length>0?d:'anonymous'}
function xd(a,b){if(a.nodeType!=1&&a.nodeType!=9){return a==b}if(b.nodeType!=1){b=b.parentNode;if(!b){return false}}if(a.nodeType==9){return a===b||a.body&&a.body.contains(b)}else{return a===b||a.contains(b)}}
function Om(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return {l:c&4194303,m:d&4194303,h:e&1048575}}
function Qm(a,b){var c,d,e,f;b&=63;c=a.h&1048575;if(b<22){f=c>>>b;e=a.m>>b|c<<22-b;d=a.l>>b|a.m<<22-b}else if(b<44){f=0;e=c>>>b-22;d=a.m>>b-22|a.h<<44-b}else{f=0;e=0;d=c>>>b-44}return {l:d&4194303,m:e&4194303,h:f&1048575}}
function Kp(a,b,c){var d,e,f,g;if(!c){return}d=0;for(g=c.hb();g.jb();){f=Uh(g.kb(),1);e=ds((Dr(),f));if(e<0){Gr(b.u,f)}else{e=Op(a,b,f);e>0&&(d|=e)}}d>0&&(b.r==-1?Hr((Dr(),b.u),d|(b.u.__eventBits||0)):(b.r|=d))}
function oe(a){var b,c,d,e,f;d=re();if(d<30){return ne(a)}else{f=2147483647;e=-1;for(b=0;b<d;b++){c=ke[b];c==0&&(c=ke[b]=$doc.styleSheets[b].cssText.length);if(c<=f){f=c;e=b}}ke[e]+=a.length;return me(e,a,true)}}
function Sp(){this.b=new kE;hE(this.b,'select');hE(this.b,'input');hE(this.b,'textarea');hE(this.b,'option');hE(this.b,RF);hE(this.b,'label');this.a=new kE;hE(this.a,LF);hE(this.a,MF);hE(this.a,SF);hE(this.a,TF)}
function hv(a,b,c){var d,e,f;if(c<0||c>a.c){throw new tz}if(a.c==a.a.length){f=Kh(jm,FE,32,a.a.length*2,0);for(d=0;d<a.a.length;++d){Mh(f,d,a.a[d])}a.a=f}++a.c;for(e=a.c-1;e>c;--e){Mh(a.a,e,a.a[e-1])}Mh(a.a,c,b)}
function an(a,b,c){var d=_m[a];if(d&&!d.cZ){_=d.prototype}else{!d&&(d=_m[a]=function(){});_=d.prototype=b<0?{}:bn(b);_.cM=c}for(var e=3;e<arguments.length;++e){arguments[e].prototype=_}if(d.cZ){_.cZ=d.cZ;d.cZ=null}}
function rh(a){if(!a){return Og(),Ng}var b=a.valueOf?a.valueOf():a;if(b!==a){var c=nh[typeof b];return c?c(b):xh(typeof b)}else if(a instanceof Array||a instanceof $wnd.Array){return new tg(a)}else{return new gh(a)}}
function _p(a,b,c,d){var e,f,g,h,i,j;Aq(a.n)+Dq(a.n).b;i=c.wb();g=d+i;for(h=d;h<g;h++){j=c.pb(h-d);f=new qA;Rc(f.a,h%2==0?'GMY2FQLAB':'GMY2FQLCB');e=new pn;new jb(h,a.n);$w(a.a,j,e);on(b,sq(h,f.a.a,new rn(e.a.a.a)))}}
function Wf(a){var b,c,d,e,f;c=a.wb();if(c==0){return null}b=new rA(c==1?'Exception caught: ':c+' exceptions caught: ');d=true;for(f=a.hb();f.jb();){e=Uh(f.kb(),57);d?(d=false):(Rc(b.a,'; '),b);pA(b,e.A())}return b.a.a}
function Vt(a){this.a=(Dr(),$doc.createElement('a'));if(!a){mo(this,this.a)}else{no(this,a);Er(this.u,this.a)}this.r==-1?Hr(this.u,1|(this.u.__eventBits||0)):(this.r|=1);fd(this.u,'gwt-Hyperlink');this.b=new Nt(this.a)}
function ro(a,b,c){if(!a){throw new wb('Null widget handle. If you are creating a composite, ensure that initWidget() has been called.')}b=Zz(b);if(b.length==0){throw new oz('Style names cannot be empty')}c?_c(a,b):dd(a,b)}
function nx(b){var c,d,e,f,g,h,i;g=Nn();if(g){try{f=Qn(g.a,FF);i=(oh(),vh(f)).M();for(d=0;d<i.a.length;d++){e=pg(i,d).O();h=ah(e,jG).P().a;c=ah(e,kG).N().a;BC(b.d,new hx(h,c))}}catch(a){a=sm(a);if(!Wh(a,51))throw rm(a)}}rx(b)}
function Cn(a){Bn();a.indexOf(AF)!=-1&&(a=en(wn,a,'&amp;'));a.indexOf(DF)!=-1&&(a=en(yn,a,'&lt;'));a.indexOf(CF)!=-1&&(a=en(xn,a,'&gt;'));a.indexOf(fF)!=-1&&(a=en(zn,a,'&quot;'));a.indexOf(EF)!=-1&&(a=en(An,a,'&#39;'));return a}
function zz(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function Pt(a,b,c){var d,e,f;if(c==(Dr(),b.u)){return}zo(b);f=null;d=new pv(a.b);while(d.b<d.c.c){e=nv(d);if(xd(c,e.u)){if(e.u==c){f=e;break}ov(d)}}ev(a.b,b);if(!f){Zc(c.parentNode,b.u,c)}else{Xc(c.parentNode,b.u,c);at(a,f)}Ao(b,a)}
function xo(a){var b;if(a.U()){throw new rz("Should only call onAttach when the widget is detached from the browser's document")}a.q=true;Dr();js(a.u,a);b=a.r;a.r=-1;b>0&&(a.r==-1?Hr(a.u,b|(a.u.__eventBits||0)):(a.r|=b));a.S();a.Y()}
function vv(a,b){var c;if(!b){throw new oz('display cannot be null')}else if(iE(a.b,b)){throw new rz('The specified display has already been added to this adapter.')}hE(a.b,b);c=Uo(b,new Av(a,b));WA(a.e,b,c);a.c>=0&&bp(b,a.c,a.d);Lv(a,b)}
function cx(a,b,c,d){var e;e=new qA;Rc(e.a,"<div class='");pA(e,Cn(c));Rc(e.a,"' data-timestamp='");pA(e,Cn(d));Rc(e.a,"'>");pA(e,a.a);Rc(e.a,' <label>');pA(e,b.a);Rc(e.a,"<\/label><button class='destroy'><\/a><\/div>");return new jn(e.a.a)}
function It(a){if(a.c){Cd(a.a.style,_F,$F);so(a.a,true);so(a.b,false);Cd(a.b.style,_F,$F)}else{so(a.a,false);Cd(a.a.style,_F,$F);Cd(a.b.style,_F,$F);so(a.b,true)}Cd(a.a.style,bG,cG);Cd(a.b.style,bG,cG);a.a=null;a.b=null;oo(a.d,false);a.d=null}
function Ic(i){var a={};var b=[];var c=arguments.callee.caller.caller;while(c){var d=i.F(c.toString());b.push(d);var e=gF+d;var f=a[e];if(f){var g,h;for(g=0,h=f.length;g<h;g++){if(f[g]===c){return b}}}(f||(a[e]=[])).push(c);c=c.caller}return b}
function de(){ce();var a,b,c;c=null;if(be.length!=0){a=be.join(cF);b=qe((je(),a));!be&&(c=b);Nb(be,0)}if(_d.length!=0){a=_d.join(cF);b=oe((je(),a));!_d&&(c=b);Nb(_d,0)}if(ae.length!=0){a=ae.join(cF);b=pe((je(),a));!ae&&(c=b);Nb(ae,0)}$d=false;return c}
function Ns(g){var d=cF;var e=$wnd.location.hash;e.length>0&&(d=g.db(e.substring(1)));Ts(d);var f=g;f.b=$wnd.onhashchange;$wnd.onhashchange=$E(function(){var a=cF,b=$wnd.location.hash;b.length>0&&(a=f.db(b.substring(1)));f.fb(a);var c=f.b;c&&c()});return true}
function Em(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return Az(c)}if(b==0&&d!=0&&c==0){return Az(d)+22}if(b!=0&&d==0&&c==0){return Az(b)+44}return -1}
function Jt(a,b,c){var d,e,f,g;$(a);d=(Dr(),rd(c.u));e=vs(rd(d),d);if(!b){so(d,true);so(c.u,true);return}a.d=b;f=rd(b.u);g=vs(rd(f),f);if(e>g){a.a=f;a.b=d;a.c=false}else{a.a=d;a.b=f;a.c=true}so(a.a,a.c);so(a.b,!a.c);a.a=null;a.b=null;oo(a.d,false);a.d=null;so(c.u,true)}
function Pm(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&524288)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?1048575:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?1048575:0;f=d?4194303:0;e=c>>b-44}return {l:e&4194303,m:f&4194303,h:g&1048575}}
function sc(a){var b,c,d,e,f,g,h;f=a.length;if(f==0){return null}b=false;c=new lb;while(mb()-c.a<100){d=false;for(e=0;e<f;e++){h=a[e];if(!h){continue}d=true;if(!h[0].C()){a[e]=null;b=true}}if(!d){break}}if(b){g=[];for(e=0;e<f;e++){!!a[e]&&Kb(g,a[e])}return g.length==0?null:g}else{return a}}
function ts(){ts=BE;ps={_default_:Es,dragenter:Ds,dragover:Ds};qs={click:Cs,dblclick:Cs,mousedown:Cs,mouseup:Cs,mousemove:Cs,mouseover:Cs,mouseout:Cs,mousewheel:Cs,keydown:Bs,keyup:Bs,keypress:Bs,touchstart:Cs,touchend:Cs,touchmove:Cs,touchcancel:Cs,gesturestart:Cs,gestureend:Cs,gesturechange:Cs}}
function au(){var c=function(){};c.prototype={className:cF,clientHeight:0,clientWidth:0,dir:cF,getAttribute:function(a,b){return this[a]},href:cF,id:cF,lang:cF,nodeType:1,removeAttribute:function(a,b){this[a]=undefined},setAttribute:function(a,b){this[a]=b},src:cF,style:{},title:cF};$wnd.GwtPotentialElementShim=c}
function iz(a){var b,c,d,e,f;if(a==null){throw new Oz(aF)}d=a.length;e=d>0&&(a.charCodeAt(0)==45||a.charCodeAt(0)==43)?1:0;for(b=e;b<d;b++){if(Wy(a.charCodeAt(b))==-1){throw new Oz(oG+a+fF)}}f=parseInt(a,10);c=f<-2147483648;if(isNaN(f)){throw new Oz(oG+a+fF)}else if(c||f>2147483647){throw new Oz(oG+a+fF)}return f}
function Dt(a,b){var c,d,e;c=(d=(Dr(),$doc.createElement(GF)),Cd(d.style,ZF,$F),Cd(d.style,_F,aG),Cd(d.style,'padding',aG),Cd(d.style,'margin',aG),d);Er(a.u,c);Zs(a,b,c);so(c,false);Cd(c.style,_F,$F);e=b.u;Uz(e.style[ZF],cF)&&(b.u.style[ZF]=$F,undefined);Uz(e.style[_F],cF)&&(b.u.style[_F]=$F,undefined);so(b.u,false)}
function tx(a){var b;this.f=new wx(this);this.d=new KC;this.b=new Mv;this.c=(Ix(),Gx);this.e=a;nx(this);b=(Lr(),Kr?Ks==null?cF:Ks:cF);this.c=Uz(b,kF)?Fx:Uz(b,lF)?Hx:Gx;Vx(a,this.f);Yx(a,this.b);Zx(a,this.c);sx(this);Mr(new Cx(this));this.a=(wy(),wy(),vy);Qf(this.a,(Hy(),Gy),new yx(this));Qf(this.a,(Ay(),zy),new Ax(this))}
function Cf(b,c){var d,e,f,g,h;if(!c){throw new Kz('Cannot fire null event')}try{++b.b;g=Ff(b,c.H());d=null;h=b.c?g.tb(g.wb()):g.sb();while(b.c?h.zb():h.jb()){f=b.c?h.Ab():h.kb();try{c.G(Uh(f,11))}catch(a){a=sm(a);if(Wh(a,57)){e=a;!d&&(d=new kE);hE(d,e)}else throw rm(a)}}if(d){throw new Uf(d)}}finally{--b.b;b.b==0&&Hf(b)}}
function Lm(a){var b,c,d,e,f;if(isNaN(a)){return Zm(),Ym}if(a<-9223372036854775808){return Zm(),Wm}if(a>=9223372036854775807){return Zm(),Vm}e=false;if(a<0){e=true;a=-a}d=0;if(a>=17592186044416){d=$h(a/17592186044416);a-=d*17592186044416}c=0;if(a>=4194304){c=$h(a/4194304);a-=c*4194304}b=$h(a);f=wm(b,c,d);e&&Cm(f);return f}
function Yp(a,b){var c,d,e,f,g,h,i,j,k,l,m;e=b.target;if(!md(e)){return}l=b.target;h=cF;c=l;while(!!c&&(h=pd(c,'__idx')).length==0){c=rd(c)}if(h.length>0){f=b.type;Uz(iF,f);g=iz(h);i=g-Dq(a.n).b;if(!(i>=0&&i<zq(a.n).k.b)){return}j=(lr(),ir)==a.n.d;m=(Vo(a,i),Bq(a.n,i));d=new jb(g,a.n);k=Fv(a,b,a,d,a.b,j);k.c||Vp(a,b,c,m)}}
function oq(a){if(!a.a){a.a=true;ce();ee('.GMY2FQLAB,.GMY2FQLCB{cursor:pointer;zoom:1;}.GMY2FQLBB{background:#ffc;}.GMY2FQLDB{height:'+(qq(),kq.a)+'px;overflow:hidden;background:url("'+kq.d.a+'") -'+kq.b+'px -'+kq.c+'px  repeat-x;background-color:#628cd5;color:white;height:auto;overflow:visible;}');return true}return false}
function Tm(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return yF}if(a.h==524288&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return '-'+Tm(Nm(a))}c=a;d=cF;while(!(c.l==0&&c.m==0&&c.h==0)){e=Mm(1000000000);c=xm(c,e,true);b=cF+Sm(tm);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;f--){b=yF+b}}d=b+d}return d}
function uh(b,c){var d;if(c&&(Qb(),Pb)){try{d=JSON.parse(b)}catch(a){return wh(vF+a)}}else{if(c){if(!(Qb(),!/[^,:{}\[\]0-9.\-+Eaeflnr-u \n\r\t]/.test(b.replace(/"(\\.|[^"\\])*"/g,cF)))){return wh('Illegal character in JSON string')}}b=Sb(b);try{d=eval(dF+b+wF)}catch(a){return wh(vF+a)}}var e=nh[typeof d];return e?e(d):xh(typeof d)}
function dq(a){var b;dp.call(this,$doc.createElement(GF));Bn();new rn(cF);this.d=new vu;this.e=new vu;this.f=new Ft;this.a=a;this.g=(rq(),lq);oq(this.g);ro((Dr(),this.u),'GMY2FQLEB',true);this.c=$doc.createElement(GF);b=this.u;Uc(b,this.c);Uc(b,lo(this.f));this.f.$(this);Dt(this.f,this.d);Dt(this.f,this.e);Kp((!Ip&&(Ip=new Sp),Ip),this,a.d)}
function wq(a,b,c){var d,e,f,g,h,i,j,k,l,m,n;Rq(a);l=-1;h=-1;m=-1;i=-1;g=0;for(e=0;e<a.length;e++){f=a[e];if(f<b||f>=c){continue}else if(l==-1){l=f;h=f}else if(m==-1){g=f-h;m=f;i=f}else{d=f-i;if(d>g){h=i;m=f;i=f;g=d}else{i=f}}}h+=1;i+=1;if(m==h){h=i;m=-1;i=-1}n=new KC;if(l!=-1){j=h-l;BC(n,new yw(l,j))}if(m!=-1){k=i-m;BC(n,new yw(m,k))}return n}
function Zw(a,b,c){var d,e,f;if(a.b==b){d=bx(b.b);pA(c.a,d.a)}else{d=cx(b.a?(e=new qA,Rc(e.a,"<input class='toggle' type='checkbox' checked>"),new jn(e.a.a)):(f=new qA,Rc(f.a,"<input class='toggle' type='checkbox'>"),new jn(f.a.a)),(Bn(),new rn(Cn(b.b))),b.a?'listItem view completed':'listItem view',cF+Tm(Lm((new WD).a.getTime())));pA(c.a,d.a)}}
function Kq(a,b,c){var d,e,f,g,h,i,j,k,l,m,n,o;o=c.wb();n=b+o;k=(!a.e?a.i:a.e).g;j=(!a.e?a.i:a.e).g+(!a.e?a.i:a.e).f;e=b>k?b:k;d=n<j?n:j;if(b!=k&&e>=d){return}l=xq(a);f=Gz(0,e-k-(!a.e?a.i:a.e).k.b);for(i=0;i<f;i++){BC(l.k,null)}for(h=e;h<d;h++){m=c.pb(h-b);g=h-k;g<(!a.e?a.i:a.e).k.b?IC(l.k,g,m):BC(l.k,m)}BC(l.c,new yw(e-f,d-(e-f)));n>(!a.e?a.i:a.e).i&&Jq(a,n,(!a.e?a.i:a.e).j)}
function ky(a){this.v=a;this.w=(new ny,ry(),my);py(this.w);this.f=yd($doc);this.a=yd($doc);this.c=yd($doc);this.g=yd($doc);this.i=yd($doc);this.k=yd($doc);this.n=yd($doc);this.o=yd($doc);this.p=yd($doc);this.r=yd($doc);this.t=yd($doc);this.d=yd($doc);this.b=new _n(this.a);this.j=new _n(this.i);this.q=new _n(this.p);this.s=new _n(this.r);this.u=new _n(this.t);this.e=new _n(this.d)}
function Am(a,b,c,d,e,f){var g,h,i,j,k,l,m;j=Dm(b)-Dm(a);g=Om(b,j);i=wm(0,0,0);while(j>=0){h=Im(a,g);if(h){j<22?(i.l|=1<<j,undefined):j<44?(i.m|=1<<j-22,undefined):(i.h|=1<<j-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}k=g.m;l=g.h;m=g.l;Fm(g,l>>>1);g.m=k>>>1|(l&1)<<21;g.l=m>>>1|(k&1)<<21;--j}c&&Cm(i);if(f){if(d){tm=Nm(a);e&&(tm=Rm(tm,(Zm(),Xm)))}else{tm=wm(a.l,a.m,a.h)}}return i}
function pm(){var a,b;cn()&&dn('com.google.gwt.useragent.client.UserAgentAsserter');a=tv();Uz(xF,a)||($wnd.alert('ERROR: Possible problem with your *.gwt.xml module file.\nThe compile time user.agent value (ie10) does not match the runtime user.agent value ('+a+'). Expect more errors.\n'),undefined);cn()&&dn('com.google.gwt.user.client.DocumentModeAsserter');Ir();cn()&&dn('com.todo.client.GwtToDo');b=new _x;new tx(b);et((gu(),ku()),b)}
function Xw(a,b,c,d){var e,f,g,h,i,j;j=d.type;if(a.b==c){if(Uz(jF,j)){h=od(d);if(h==13){Vw(a,b,c);a.b=null;_w(a,b,c)}h==27&&(a.b=null,_w(a,b,c))}if(Uz(MF,j)&&!a.a){Vw(a,b,c);a.b=null;_w(a,b,c)}}else{if(Uz(VF,j)){a.b=c;_w(a,b,c);a.a=true;g=Wc(b.firstChild);ad(g);a.a=false}if(Uz(iF,j)){f=d.target;e=f;i=e.tagName;if(Uz(i,hG)){g=e;ex(c,Ad(g));sf(a.c,new Jy(c));Ad(g)?_c(b.firstChild,iG):dd(b.firstChild,iG)}else Uz(i,YF)&&sf(a.c,new Cy(c))}}}
function tv(){var b=navigator.userAgent.toLowerCase();var c=function(a){return parseInt(a[1])*1000+parseInt(a[2])};if(function(){return b.indexOf('webkit')!=-1}())return 'safari';if(function(){return b.indexOf(eG)!=-1&&$doc.documentMode>=10}())return xF;if(function(){return b.indexOf(eG)!=-1&&$doc.documentMode>=9}())return 'ie9';if(function(){return b.indexOf(eG)!=-1&&$doc.documentMode>=8}())return 'ie8';if(function(){return b.indexOf('gecko')!=-1}())return 'gecko1_8';return 'unknown'}
function Lq(a,b,c){var d,e,f,g,h,i,j,k,l,m;m=b.b;g=b.a;if(m<0){throw new oz('Range start cannot be less than 0')}if(g<0){throw new oz('Range length cannot be less than 0')}j=(!a.e?a.i:a.e).g;h=(!a.e?a.i:a.e).f;k=j!=m;if(k){l=xq(a);if(!c){if(m>j){f=m-j;if((!a.e?a.i:a.e).k.b>f){for(e=0;e<f;e++){GC(l.k,0)}}else{DC(l.k)}}else{d=j-m;if((!a.e?a.i:a.e).k.b>0&&d<h){for(e=0;e<d;e++){AC(l.k,0,null)}BC(l.c,new yw(m,m+d-m))}else{DC(l.k)}}}l.g=m}i=h!=g;i&&(xq(a).f=g);c&&DC(xq(a).k);Mq(a);(k||i)&&Hw(a.a,new yw((!a.e?a.i:a.e).g,(!a.e?a.i:a.e).f))}
function Hq(a,b,c,d){var e,f,g,h,i,j,k,l;if((lr(),jr)==a.d){return}a.c.a&&(b=Gz(0,Hz(b,(!a.e?a.i:a.e).k.b-1)));xq(a).p=true;if(!d&&(jr==a.d?-1:(!a.e?a.i:a.e).d)==b&&(jr==a.d?null:(!a.e?a.i:a.e).e)!=null){return}i=(!a.e?a.i:a.e).g;h=(!a.e?a.i:a.e).f;k=(!a.e?a.i:a.e).i;e=i+b;e>=k&&(!a.e?a.i:a.e).j&&(e=k-1);b=(0>e?0:e)-i;a.c.a&&(b=0>(b<h-1?b:h-1)?0:b<h-1?b:h-1);g=i;f=h;j=xq(a);j.d=0;j.e=null;j.a=true;if(b>=0&&b<h){j.d=b;j.e=b<j.k.b?Wq(xq(a),b):null;j.b=c;return}else if((dr(),ar)==a.c){while(b<0){l=h<g?h:g;g-=l;b+=l}while(b>=h){g+=h;b-=h}}else if(cr==a.c){while(b<0){l=30<g?30:g;f+=l;g-=l;b+=l}while(b>=f){f+=30}if((!a.e?a.i:a.e).j){f=f<k-g?f:k-g;b>=k&&(b=k-1)}}if(g!=i||f!=h){j.d=b;Lq(a,new yw(g,f),false)}}
function xm(a,b,c){var d,e,f,g,h,i,j,k;if(b.l==0&&b.m==0&&b.h==0){throw new Ny}if(a.l==0&&a.m==0&&a.h==0){c&&(tm=wm(0,0,0));return wm(0,0,0)}if(b.h==524288&&b.m==0&&b.l==0){return ym(a,c)}i=false;if(b.h>>19!=0){b=Nm(b);i=true}g=Em(b);f=false;e=false;d=false;if(a.h==524288&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=vm((Zm(),Vm));d=true;i=!i}else{h=Pm(a,g);i&&Cm(h);c&&(tm=wm(0,0,0));return h}}else if(a.h>>19!=0){f=true;a=Nm(a);d=true;i=!i}if(g!=-1){return zm(a,g,i,f,c)}if(!(j=a.h>>19,k=b.h>>19,j==0?k!=0||a.h>b.h||a.h==b.h&&a.m>b.m||a.h==b.h&&a.m==b.m&&a.l>=b.l:!(k==0||a.h<b.h||a.h==b.h&&a.m<b.m||a.h==b.h&&a.m==b.m&&a.l<b.l))){c&&(f?(tm=Nm(a)):(tm=wm(a.l,a.m,a.h)));return wm(0,0,0)}return Am(d?a:wm(a.l,a.m,a.h),b,i,f,e,c)}
function ds(a){switch(a){case MF:return 4096;case 'change':return 1024;case iF:return 1;case VF:return 2;case LF:return 2048;case NF:return 128;case 'keypress':return 256;case jF:return 512;case SF:return 32768;case 'losecapture':return 8192;case OF:return 4;case 'mousemove':return 64;case 'mouseout':return 32;case 'mouseover':return 16;case 'mouseup':return 8;case 'scroll':return 16384;case TF:return 65536;case 'DOMMouseScroll':case 'mousewheel':return 131072;case 'contextmenu':return 262144;case 'paste':return 524288;case 'touchstart':return 1048576;case 'touchmove':return 2097152;case 'touchend':return 4194304;case 'touchcancel':return 8388608;case 'gesturestart':return 16777216;case 'gesturechange':return 33554432;case 'gestureend':return 67108864;default:return -1;}}
function jy(a){var b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r;c=new Qt(ty(a.a,a.c,a.g,a.i,a.k,a.n,a.o,a.p,a.r,a.t,a.d).a);b=bo((Dr(),c.u));$n(a.b);d=$n(new _n(a.c));a.v.c=d;e=$n(new _n(a.g));a.v.o=e;$n(a.j);f=$n(new _n(a.k));a.v.k=f;g=$n(new _n(a.n));a.v.d=g;h=$n(new _n(a.o));a.v.e=h;$n(a.q);$n(a.s);$n(a.u);$n(a.e);b.b?Xc(b.b,b.a,b.c):eo(b.a);Pt(c,(i=new Tw,ed(i.u,'placeholder','What needs to be done?'),a.v.j=i,i),$n(a.b));Pt(c,a.v.n,$n(a.j));Pt(c,(j=new Ut,St(j,(p=new qA,Rc(p.a,'All'),new jn(p.a.a)).a),fd(j.u,mG),Tt(j,'/'),a.v.g=j,j),$n(a.q));Pt(c,(k=new Ut,St(k,(q=new qA,Rc(q.a,'Active'),new jn(q.a.a)).a),fd(k.u,mG),Tt(k,kF),a.v.f=k,k),$n(a.s));Pt(c,(l=new Ut,St(l,(r=new qA,Rc(r.a,'Completed'),new jn(r.a.a)).a),fd(l.u,mG),Tt(l,lF),a.v.i=l,l),$n(a.u));Pt(c,(m=new At,yt(m,sy(a.f).a),n=bo(m.u),o=$n(new _n(a.f)),a.v.b=o,n.b?Xc(n.b,n.a,n.c):eo(n.a),a.v.a=m,m),$n(a.e));return c}
function Ir(){var a,b,c;b=$doc.compatMode;a=Lh(om,FE,1,[UF]);for(c=0;c<a.length;c++){if(Uz(a[c],b)){return}}a.length==1&&Uz(UF,a[0])&&Uz('BackCompat',b)?"GWT no longer supports Quirks Mode (document.compatMode=' BackCompat').<br>Make sure your application's host HTML page has a Standards Mode (document.compatMode=' CSS1Compat') doctype,<br>e.g. by using &lt;!doctype html&gt; at the start of your application's HTML page.<br><br>To continue using this unsupported rendering mode and risk layout problems, suppress this message by adding<br>the following line to your*.gwt.xml module file:<br>&nbsp;&nbsp;&lt;extend-configuration-property name=\"document.compatMode\" value=\""+b+'"/&gt;':"Your *.gwt.xml module configuration prohibits the use of the current doucment rendering mode (document.compatMode=' "+b+"').<br>Modify your application's host HTML page doctype, or update your custom 'document.compatMode' configuration property settings."}
function Ub(){var a=['\\u0000','\\u0001','\\u0002','\\u0003','\\u0004','\\u0005','\\u0006','\\u0007','\\b','\\t','\\n','\\u000B','\\f','\\r','\\u000E','\\u000F','\\u0010','\\u0011','\\u0012','\\u0013','\\u0014','\\u0015','\\u0016','\\u0017','\\u0018','\\u0019','\\u001A','\\u001B','\\u001C','\\u001D','\\u001E','\\u001F'];a[34]='\\"';a[92]='\\\\';a[173]='\\u00ad';a[1536]='\\u0600';a[1537]='\\u0601';a[1538]='\\u0602';a[1539]='\\u0603';a[1757]='\\u06dd';a[1807]='\\u070f';a[6068]='\\u17b4';a[6069]='\\u17b5';a[8203]='\\u200b';a[8204]='\\u200c';a[8205]='\\u200d';a[8206]='\\u200e';a[8207]='\\u200f';a[8232]='\\u2028';a[8233]='\\u2029';a[8234]='\\u202a';a[8235]='\\u202b';a[8236]='\\u202c';a[8237]='\\u202d';a[8238]='\\u202e';a[8288]='\\u2060';a[8289]='\\u2061';a[8290]='\\u2062';a[8291]='\\u2063';a[8292]='\\u2064';a[8298]='\\u206a';a[8299]='\\u206b';a[8300]='\\u206c';a[8301]='\\u206d';a[8302]='\\u206e';a[8303]='\\u206f';a[65279]='\\ufeff';a[65529]='\\ufff9';a[65530]='\\ufffa';a[65531]='\\ufffb';return a}
function ty(a,b,c,d,e,f,g,h,i,j,k){var l;l=new qA;Rc(l.a,"<section id='todoapp'> <header id='header'> <h1>todos<\/h1> <span id='");pA(l,Cn(a));Rc(l.a,"'><\/span> <\/header> <section id='");pA(l,Cn(b));Rc(l.a,"'> <input id='");pA(l,Cn(c));Rc(l.a,"' type='checkbox'> <label for='toggle-all'>Mark all as complete<\/label> <div id='todo-list'> <span id='");pA(l,Cn(d));Rc(l.a,"'><\/span> <\/div> <\/section> <footer id='");pA(l,Cn(e));Rc(l.a,"'> <span id='todo-count'> <strong class='number' id='");pA(l,Cn(f));Rc(l.a,"'><\/strong> <span class='word' id='");pA(l,Cn(g));Rc(l.a,"'><\/span> left <\/span> <ul id='filters'> <li> <span id='");pA(l,Cn(h));Rc(l.a,nG);pA(l,Cn(i));Rc(l.a,nG);pA(l,Cn(j));Rc(l.a,"'><\/span> <\/li> <\/ul> <span id='");pA(l,Cn(k));Rc(l.a,"'><\/span> <\/footer> <\/section> <footer id='info'> <p>Double-click to edit a todo<\/p> <p>Created by <a href='http://www.scottlogic.co.uk/blog/colin/'>Colin Eberhardt<\/a><\/p> <p>Part of <a href='http://todomvc.com'>TodoMVC<\/a><\/p> <\/footer>");return new jn(l.a.a)}
function As(a,b){var c=(a.__eventBits||0)^b;a.__eventBits=b;if(!c)return;c&1&&(a.onclick=b&1?rs:null);c&2&&(a.ondblclick=b&2?rs:null);c&4&&(a.onmousedown=b&4?rs:null);c&8&&(a.onmouseup=b&8?rs:null);c&16&&(a.onmouseover=b&16?rs:null);c&32&&(a.onmouseout=b&32?rs:null);c&64&&(a.onmousemove=b&64?rs:null);c&128&&(a.onkeydown=b&128?rs:null);c&256&&(a.onkeypress=b&256?rs:null);c&512&&(a.onkeyup=b&512?rs:null);c&1024&&(a.onchange=b&1024?rs:null);c&2048&&(a.onfocus=b&2048?rs:null);c&4096&&(a.onblur=b&4096?rs:null);c&8192&&(a.onlosecapture=b&8192?rs:null);c&16384&&(a.onscroll=b&16384?rs:null);c&32768&&(a.onload=b&32768?ss:null);c&65536&&(a.onerror=b&65536?rs:null);c&131072&&(a.onmousewheel=b&131072?rs:null);c&262144&&(a.oncontextmenu=b&262144?rs:null);c&524288&&(a.onpaste=b&524288?rs:null);c&1048576&&(a.ontouchstart=b&1048576?rs:null);c&2097152&&(a.ontouchmove=b&2097152?rs:null);c&4194304&&(a.ontouchend=b&4194304?rs:null);c&8388608&&(a.ontouchcancel=b&8388608?rs:null);c&16777216&&(a.ongesturestart=b&16777216?rs:null);c&33554432&&(a.ongesturechange=b&33554432?rs:null);c&67108864&&(a.ongestureend=b&67108864?rs:null)}
function Sr(){var a,b;if(!Or){a=(b=$doc.createElement('script'),ud(b,'function __gwt_initWindowCloseHandler(beforeunload, unload) {\n  var wnd = window\n  , oldOnBeforeUnload = wnd.onbeforeunload\n  , oldOnUnload = wnd.onunload;\n  \n  wnd.onbeforeunload = function(evt) {\n    var ret, oldRet;\n    try {\n      ret = beforeunload();\n    } finally {\n      oldRet = oldOnBeforeUnload && oldOnBeforeUnload(evt);\n    }\n    // Avoid returning null as IE6 will coerce it into a string.\n    // Ensure that "" gets returned properly.\n    if (ret != null) {\n      return ret;\n    }\n    if (oldRet != null) {\n      return oldRet;\n    }\n    // returns undefined.\n  };\n  \n  wnd.onunload = function(evt) {\n    try {\n      unload();\n    } finally {\n      oldOnUnload && oldOnUnload(evt);\n      wnd.onresize = null;\n      wnd.onscroll = null;\n      wnd.onbeforeunload = null;\n      wnd.onunload = null;\n    }\n  };\n  \n  // Remove the reference once we\'ve initialize the handler\n  wnd.__gwt_initWindowCloseHandler = undefined;\n}\n'),b);Uc($doc.body,a);$wnd.__gwt_initWindowCloseHandler($E(Ur),$E(Tr));Yc($doc.body,a);Or=true}}
function Fq(b,c){var d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,A,B,C,D,F,G,H,I,J,K,L,M,N,O,P,Q,R,S;b.f=null;if(b.b){return false}b.b=true;if(!b.e){b.b=false;b.g=0;return false}++b.g;if(b.g>10){b.b=false;b.g=0;throw new rz('A possible infinite loop has been detected in a Cell Widget. This usually happens when your SelectionModel triggers a SelectionChangeEvent when SelectionModel.isSelection() is called, which causes the table to redraw continuously.')}t=b.i;l=b.e;b.i=b.e;b.e=null;!c&&(c=[]);B=l.g;A=l.f;w=B+A;O=l.k.b;l.d=Gz(0,Hz(l.d,O-1));if((lr(),jr)==b.d){l.d=0;l.e=null}else if(l.a){l.e=O>0?Wq(l,l.d):null}else if(l.e!=null){e=yq(l,l.e,l.d);if(e>=0){l.d=e;l.e=O>0?Wq(l,l.d):null}else{l.d=0;l.e=null}}try{if(ir==b.d&&false){u=t.o;m=O>0?Wq(l,l.d):null;if(m!=null){v=u!=null&&null.Kb();n=m!=null&&null.Kb();if(Ib(m,u)){n||(l.o=null)}else{v&&null.Kb();l.o=m;m!=null&&!n&&null.Kb()}}}}catch(a){a=sm(a);if(Wh(a,55)){f=a;b.b=false;b.g=0;throw rm(f)}else throw rm(a)}h=l.a||t.d!=l.d||t.e==null&&l.e!=null;o=new kE;try{for(g=B;g<B+O;g++){EC(l.k,g-B);Q=iE(t.n,Dz(g));Q&&Lb(c,g)}}catch(a){a=sm(a);if(Wh(a,55)){f=a;b.b=false;b.g=0;throw rm(f)}else throw rm(a)}L=false;for(N=new _B(l.c);N.b<N.d.wb();){M=Uh(ZB(N),35);P=M.b;i=M.a;i==0&&(L=true);for(g=P;g<P+i;g++){Lb(c,g)}}if(c.length>0&&h){Lb(c,t.d);Lb(c,l.d)}if(b.e){b.b=false;b.e.o=l.o;b.e.n.Cb(o);h&&(b.e.a=true);l.b&&(b.e.b=true);Lb(c,t.d);Lb(c,l.d);if(Fq(b,c)){return true}}j=wq(c,B,w);F=j.b>0?(LB(0,j.b),Uh(j.a[0],35)):null;G=j.b>1?(LB(1,j.b),Uh(j.a[1],35)):null;J=0;for(D=new _B(j);D.b<D.d.wb();){C=Uh(ZB(D),35);J+=C.a}q=t.g;p=t.f;r=t.k.b;H=false;B!=q?(H=true):O<r?(H=true):!G&&!!F&&F.b==B&&(J>=r||J>p)?(H=true):J>=5&&J>0.3*r?(H=true):L&&r==0&&(H=true);R=(!b.e?b.i:b.e).k.b;S=(!b.e?b.i:b.e).j?Hz((!b.e?b.i:b.e).f,(!b.e?b.i:b.e).i-(!b.e?b.i:b.e).g):(!b.e?b.i:b.e).f;R>=S?Ap(b.j,(zr(),wr)):R==0?Ap(b.j,(zr(),xr)):Ap(b.j,(zr(),yr));try{if(H){new pn;wp(b.j,l.k,l.b);yp(b.j)}else if(F){d=F.b;I=d-B;new pn;K=new iC(l.k,I,I+F.a);xp(b.j,K,I,l.b);if(G){d=G.b;I=d-B;new pn;K=new iC(l.k,I,I+G.a);xp(b.j,K,I,l.b)}yp(b.j)}else if(h){s=t.d;s>=0&&s<O&&zp(b.j,s,false,false);k=l.d;k>=0&&k<O&&zp(b.j,k,true,l.b)}}catch(a){a=sm(a);if(Wh(a,50)){f=a;throw new yb(f)}else throw rm(a)}finally{b.b=false}Fq(b,null);return true}
function En(){this.a='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFIAAAAaCAYAAAAkJwuaAAAHt0lEQVR42u1SWVeURxD9fiqLuOFugp5ojjsuzMBIEDXHFSOKRIHI9kNmBgYERkHEhWQcQB47XWtX94xPyaMP91RX1a1bt76ZrG961/XNBPROf3N9syEvzMZ1jDO7jZhtfAMX52fNe4bnjY5oCjetx7rfIl+pXgHfpi+a3/M9sxvdlUboRd/A9MO3+uYySPLTO764wxHyUEv7eRbIa27n4mgRa3/Tt61Zrd7v1prvEG8Bu4nP5l56k3vi+3cbZuKdYW+Wn9rGJDdFwNwjN+nzyW2G9KS2RXFqSznam5IcdO17h3Lo465t5eent7QGnLzujd8KvxdnJsW7eOZcdCd3ON+Kenn0tMX7hC+3hzzcs0Mz0zsufK/taD678deWE/S85ncStc7vHunB+/V2qL+OZ+2cziO3Hmr+DRrxjnrQg9oEoB68mF7k2XqYYE+TW9Gc3qRekv5EvcGz6Ik+cet0B+/Jro1/ddfG6+7a2Fd3dbzmro4BfG0CcgJyJoBTw3jdA7gQsT5RYx7nfv46zGOsoxZwcNZzUB+44zXdQxzag/kYY7zOs7xvvB57klmuiXfSD36CvszVlX+dta5P1I1GTW+jnaQFPb1rvK6a2ZWX/zhAN+PKq5BDvPyy5rrHoO7jq6++ZnPiIP8VzNRofizUr1iO/yG6hQtvbwj7jMvIYbykfd3pXtSuEUCHfZCn4EU0YY/W/b7ul7RHvHVHHmuhZ/Ox+I7L9nuNkW528c+/HeASQ94XRzfNO/QuvKA61GyfdDZDfTTWDJx0T8ClRM/2I51R2nVJdtr3qKlFvKAf8s34vlG6O3DiWXtjWs/OPf/izo8APjt6QxSE/PzIZoD/mOe5h32OCJmF94vPxB2hSDrw/oI6oK/cEbtzE2vnrDZrnROvii+860vQey75Z90pPNl3AfojPDMSe470Rqzm58B9Hr4LxOzs8Ib79dlHd/YpwL+HP3lw7t9Qk/rZpwTo//qMefCG3jDNgx7MYp915Q2RND+aHfQ+gzs+sk7wgH6esY9kBv2g30/sgeIZ2Tn8KdyA7w2e4ZuHrR/pi3/7DT6qBt3CO58xz89lv/zxwUV4AnGDcxOfbHBu37Zn+Jp/CPnQh+/MmRrsHvrQqIWwPesN6nZ/sju9I+pvNJ95Ym568r25eEd2+vG663q05iCe8vHUo/fu1OP3PodoahAfvw/QmXXiD9GMBXKGZIbnI33hroca6q0HP6LNOKX8ddXA95B49L0h63eNdsgs6qyrjvod4nutrvX/iHDafgP0SLzs5werruvBmoNI8O+HnD9cDW/be8i9ByF2ab4WuDrXRCvdYfUeyvya0VnDHxz2dKlHyJtoPmjij+fphtRP7FVvifyYHU362Yl779xJhr7vx2/bOyHv+6s6d/LeqrM6kFtu1MM54Nv5dw3z0v/p/qrRWdW9J4y3Ru3GnannhrsjzmoTT83uDsiO//7WHUOsYDyuWHHUq5pawDGN0K/ifGN8m2iI5kqkGzSqTfYEvWMY35pceFXjZ8XMV6P+MVOLb61GIB8riZ9q5DXdmR25u+KO3Fl2RyF6HGUcubvsUcUevEO9yvwq5XeYyzziVpFHMxKXmVtVrbDTzi4bP5QrF3esqJ76kf3sK3jmaG6wUd/Jjek+ywt3xPzs0O0ld/j2sseSOzS4RBGxrPnhO1SLOIPEOaxYatDAOdFgPYFy73CPIfvCrPEBGIz3HG7iy9ZTNOvbWoO/iLNsbo/7WefAkjs48MbDx1tv8N3pYydE7S26zkGOt0IfZjpvEUf6pLFI87eoTjNmtgFL+qb9S6zdfDbsXWRPcBTvh96g+It9H5R52WfvEx8DokteSPeN8lQD30v6zg70LzrEbws+VtyBAckJ+/sXqOb78MYcepY3wLM+3w86zIX8YKS3EGsjt8KaMAMaC2RSdjP29y+qjwP9wQvpV0iLtaGGWrITovhGVPQGuU/84g2gx98ixAXaIVzR5Vq272bF7bu54Ch6wADEgtTn/Zujx94CcahWCX2o3ZS6iczBOdlxM5n12FuY93tlXyXe15AzV/b2Bz2sS834JlR4hjzs1zl7Z/I9NLee502P3tnevorr6Jtzez06+sAovQnzoe7RwYCj4SCcK8xznMMYtLhWEP689mhHhXXNnNeUumgjZKYwr57En3juKMzpXOSrr2JusHeae4xv2iP3JP1C4GjO3yHb01t2e3rn3J48oQPeHu15rktPOfNab5e65Zh6u9eWt+jG3HLzmDdIZtqtT9vvDXvakxrw2u18bznqx3eU49t7E/9NdgKytlwJhdryJRRoYyGKvp7jCDXmtkvPz1C9zLVy1Fee7MiBru0DShrbolo54ZWNz7moT/vjOu0qNfHEu5Jbgl56j62V1FuqncGHaPWk1p6SRxEXUIR6CQdac0X+YEWqCfiDIz9f5FjmXhF1IdIHL9EO0OgpkT7zW3NsLldkfpk5MiMeJC/r7jbxxse28gfEOnsUDZzP0w1yI91S1D9FvK+sd6AfuU3vK+l9mRzWeqOoH1MPjmpF1yJ5rqQf1H4c5OeKmhNfNIJB1WQd4bXYfTnObxgt2cdaLT3F2K/Z0ZJ4aeX5lh6pWz/El5nYR7JLZsUb9zM19gP/CT8+5P+EfwFEPZjKzXkk0QAAAABJRU5ErkJggg=='}
var cF='',hF=' ',fF='"',WF='#',XF='%23',AF='&',EF="'",nG="'><\/span> <\/li> <li> <span id='",dF='(',wF=')',qF=',',tF=', ',gG=', Size: ',kF='/active',lF='/completed',yF='0',aG='0px',$F='100%',gF=':',_E=': ',DF='<',pG='=',CF='>',YF='BUTTON',UF='CSS1Compat',vF='Error parsing JSON: ',IG='EventBus',oG='For input string: "',PF='GMY2FQLBB',mG='GMY2FQLEI',hG='INPUT',fG='Index: ',JG='SimpleEventBus',bF='String',zG='UmbrellaException',pF='[',DG='[Lcom.google.gwt.user.cellview.client.',FG='[Lcom.google.gwt.user.client.ui.',tG='[Ljava.lang.',rF=']',QF='__gwtCellBasedWidgetImplDispatching',IF='aria-hidden',MF='blur',RF='button',iF='click',QG='com.google.gwt.animation.client.',LG='com.google.gwt.cell.client.',sG='com.google.gwt.core.client.',AG='com.google.gwt.core.client.impl.',RG='com.google.gwt.dom.client.',PG='com.google.gwt.event.dom.client.',CG='com.google.gwt.event.logical.shared.',xG='com.google.gwt.event.shared.',GG='com.google.gwt.i18n.client.',NG='com.google.gwt.json.client.',SG='com.google.gwt.safehtml.shared.',MG='com.google.gwt.storage.client.',UG='com.google.gwt.text.shared.testing.',TG='com.google.gwt.uibinder.client.',BG='com.google.gwt.user.cellview.client.',HG='com.google.gwt.user.client.',OG='com.google.gwt.user.client.impl.',uG='com.google.gwt.user.client.ui.',EG='com.google.gwt.view.client.',wG='com.google.web.bindery.event.shared.',vG='com.todo.client.',yG='com.todo.client.events.',kG='complete',iG='completed',VF='dblclick',mF='dir',KF='display',GF='div',TF='error',LF='focus',qG='fromIndex: ',eF='function',BF='g',_F='height',zF='html is null',xF='ie10',rG='java.lang.',KG='java.util.',NF='keydown',jF='keyup',SF='load',oF='ltr',OF='mousedown',eG='msie',HF='none',aF='null',bG='overflow',nF='rtl',lG='selected',jG='task',FF='todo-gwt',JF='true',dG='value',cG='visible',ZF='width',sF='{',uF='}';var _,_m={},GE={44:1,51:1,55:1,57:1},HE={3:1,4:1,44:1,47:1,49:1},EE={},JE={38:1,44:1,51:1,55:1,57:1},SE={31:1,44:1,47:1,49:1},XE={63:1},LE={19:1,44:1},KE={7:1,11:1},FE={44:1},NE={9:1,12:1,24:1,25:1,27:1,28:1,30:1,32:1},PE={11:1,33:1},RE={9:1,12:1,24:1,25:1,26:1,28:1,29:1,30:1,32:1},UE={37:1},ME={9:1,12:1,24:1,25:1,28:1,30:1,32:1},VE={46:1},IE={12:1},OE={9:1,12:1,24:1,25:1,27:1,28:1,30:1,32:1,34:1},ZE={44:1,60:1},YE={62:1},WE={61:1},QE={9:1,12:1,24:1,25:1,26:1,28:1,30:1,32:1},TE={60:1};an(1,-1,EE,V);_.eQ=function W(a){return this===a};_.gC=function X(){return this.cZ};_.hC=function Y(){return ec(this)};_.tS=function Z(){return this.cZ.c+'@'+Bz(this.hC())};_.toString=function(){return this.tS()};_.tM=BE;an(3,1,{});_.e=false;_.f=false;_.g=false;an(4,1,{});an(5,4,{});an(6,5,{},fb);an(7,1,{});an(8,1,{},jb);_.a=0;an(9,1,{},lb);_.a=0;an(14,1,{44:1,57:1});_.A=function tb(){return this.e};_.tS=function ub(){return sb(this)};an(13,14,{44:1,51:1,57:1});an(12,13,GE,wb,yb);an(11,12,{2:1,44:1,51:1,55:1,57:1},Cb);_.A=function Fb(){Bb(this);return this.c};_.B=function Gb(){return this.b===zb?null:this.b};var zb;var Ob,Pb=false;an(21,1,{});var Wb=0,Xb=0,Yb=0,Zb=-1;an(23,21,{},vc);_.d=false;_.i=false;var lc;an(24,1,{},Bc);_.C=function Cc(){this.a.d=true;pc(this.a);this.a.d=false;return this.a.i=qc(this.a)};an(25,1,{},Ec);_.C=function Fc(){this.a.d&&zc(this.a.e,1);return this.a.i};an(28,1,{},Mc);_.F=function Nc(a){return Gc(a)};an(29,1,{});an(30,29,{},Sc);_.a=cF;an(48,1,{44:1,47:1,49:1});_.eQ=function Gd(a){return this===a};_.hC=function Hd(){return ec(this)};_.tS=function Id(){return this.b};_.c=0;an(47,48,HE);var Jd,Kd,Ld,Md,Nd;an(49,47,HE,Sd);an(50,47,HE,Ud);an(51,47,HE,Wd);an(52,47,HE,Yd);var Zd,$d=false,_d,ae,be;an(55,1,{},he);_.D=function ie(){(ce(),$d)&&de()};var ke;an(63,1,{});_.tS=function ye(){return 'An event type'};an(62,63,{});_.g=false;an(61,62,{});_.H=function Ee(){return this.I()};var Ae;an(60,61,{});an(59,60,{});an(58,59,{},He);_.G=function Ie(a){kx(Uh(Uh(a,5),41).a.a)};_.I=function Je(){return Fe};var Fe;an(66,1,{});_.hC=function Oe(){return this.c};_.tS=function Pe(){return 'Event type'};_.c=0;var Ne=0;an(65,66,{},Qe);an(64,65,{6:1},Re);an(68,61,{});an(67,68,{});an(69,67,{},Xe);_.G=function Ye(a){Uh(a,7).J(this)};_.I=function Ze(){return Ve};var Ve;an(70,1,{},bf);an(72,62,{},ef);_.G=function ff(a){Uh(a,8);ju()};_.H=function hf(){return df};var df;an(73,62,{},mf);_.G=function nf(a){lf(this,Uh(a,10))};_.H=function pf(){return kf};var kf;an(75,1,{});an(74,75,IE);an(76,1,IE,wf);an(78,75,{},If);_.K=function Kf(a,b,c){this.b>0?zf(this,new Qw(this,a,c)):Df(this,a,c)};_.b=0;_.c=false;an(77,78,{},Lf);_.K=function Mf(a,b,c){this.b>0?zf(this,new Qw(this,a,c)):Df(this,a,c)};an(79,1,{},Of);an(80,74,IE,Rf);an(82,12,JE,Uf);an(81,82,JE,Xf);an(83,1,KE,Zf);_.J=function $f(a){};an(85,48,{13:1,44:1,47:1,49:1},hg);var cg,dg,eg,fg;an(87,1,{});_.M=function lg(){return null};_.N=function mg(){return null};_.O=function ng(){return null};_.P=function og(){return null};an(86,87,{14:1},sg,tg);_.eQ=function ug(a){if(!Wh(a,14)){return false}return this.a==Uh(a,14).a};_.L=function vg(){return zg};_.hC=function wg(){return ec(this.a)};_.M=function xg(){return this};_.tS=function yg(){return rg(this)};an(88,87,{},Eg);_.L=function Fg(){return Ig};_.N=function Gg(){return this};_.tS=function Hg(){return Ry(),cF+this.a};_.a=false;var Bg,Cg;an(89,12,GE,Kg,Lg);an(90,87,{},Pg);_.L=function Qg(){return Sg};_.tS=function Rg(){return aF};var Ng;an(91,87,{15:1},Ug);_.eQ=function Vg(a){if(!Wh(a,15)){return false}return this.a==Uh(a,15).a};_.L=function Wg(){return Zg};_.hC=function Xg(){return $h((new jz(this.a)).a)};_.tS=function Yg(){return this.a+cF};_.a=0;an(92,87,{16:1},fh,gh);_.eQ=function hh(a){if(!Wh(a,16)){return false}return this.a==Uh(a,16).a};_.L=function ih(){return mh};_.hC=function jh(){return ec(this.a)};_.O=function kh(){return this};_.tS=function lh(){var a,b,c,d,e,f;f=new lA;Rc(f.a,sF);a=true;e=_g(this,Kh(om,FE,1,0,0));for(c=0,d=e.length;c<d;++c){b=e[c];a?(a=false):(Rc(f.a,tF),f);kA(f,Tb(b));Rc(f.a,gF);jA(f,ah(this,b))}Rc(f.a,uF);return f.a.a};var nh;an(94,87,{17:1},zh);_.eQ=function Ah(a){if(!Wh(a,17)){return false}return Uz(this.a,Uh(a,17).a)};_.L=function Bh(){return Fh};_.hC=function Ch(){return gA(this.a)};_.P=function Dh(){return this};_.tS=function Eh(){return Tb(this.a)};an(95,1,{},Gh);_.qI=0;var Nh,Oh;var tm;var Jm;var Vm,Wm,Xm,Ym;an(108,1,{},gn);_.a=0;_.b=0;_.c=0;an(109,1,LE,jn);_.Q=function kn(){return this.a};_.eQ=function ln(a){if(!Wh(a,19)){return false}return Uz(this.a,Uh(a,19).Q())};_.hC=function mn(){return gA(this.a)};an(110,1,{},pn);an(111,1,LE,rn);_.Q=function sn(){return this.a};_.eQ=function tn(a){if(!Wh(a,19)){return false}return Uz(this.a,Uh(a,19).Q())};_.hC=function un(){return gA(this.a)};_.tS=function vn(){return 'safe: "'+this.a+fF};var wn,xn,yn,zn,An;an(113,1,{20:1,21:1},En);_.eQ=function Fn(a){if(!Wh(a,20)){return false}return Uz(this.a,Uh(Uh(a,20),21).a)};_.hC=function Gn(){return gA(this.a)};an(115,1,{},Mn);var Jn,Kn;an(116,1,{},Pn);_.a=false;an(119,1,{});an(120,1,{},Vn);var Un;an(121,119,{},Yn);var Xn;an(122,1,{},_n);var ao;an(124,1,{},go);an(128,1,{25:1,30:1});_.R=function qo(){throw new uA};_.tS=function to(){if(!this.u){return '(null handle)'}return (Dr(),this.u).outerHTML};an(127,128,ME);_.S=function Co(){};_.T=function Do(){};_.U=function Eo(){return this.q};_.V=function Fo(){xo(this)};_.W=function Go(a){yo(this,a)};_.X=function Ho(){if(!this.U()){throw new rz("Should only call onDetach when the widget is attached to the browser's document")}try{this.Z()}finally{try{this.T()}finally{Dr();js(this.u,null);this.q=false}}};_.Y=function Io(){};_.Z=function Jo(){};_.$=function Ko(a){Ao(this,a)};_.q=false;_.r=0;an(126,127,NE);_.U=function No(){return Mo(this)};_.V=function Oo(){if(this.r!=-1){Bo(this.p,this.r);this.r=-1}this.p.V();Dr();js(this.u,this)};_.W=function Po(a){yo(this,a);this.p.W(a)};_.X=function Qo(){try{this.Z()}finally{this.p.X()}};_.R=function Ro(){no(this,(Dr(),this.p.R()));return this.u};an(125,126,OE);_._=function gp(){return Dq(this.n)};_.W=function hp(a){var b,c,d,e;!Ip&&(Ip=new Sp);if(this.j){return}b=a.target;if(!md(b)){return}d=b;if(!xd((Dr(),this.u),b)){return}yo(this,a);this.p.W(a);c=a.type;if(Uz(LF,c)){this.i=true;Zp(this)}else if(Uz(MF,c)){this.i=false;e=Wp(this);!!e&&dd(e,PF)}else Uz(NF,c)?(this.i=true):Uz(OF,c)&&(!Ip&&(Ip=new Sp),Jp(Ip,d))&&(this.i=true);Yp(this,a)};_.Z=function ip(){this.i=false};_.ab=function lp(a,b){bp(this,a,b)};_.bb=function mp(a,b){Kq(this.n,a,b)};_.i=false;_.j=false;_.o=0;var So;an(129,127,ME,op);an(130,1,PE,rp);_.cb=function sp(a){var b,c,d,e,f,g,h;d=a.f;b=a.f.type;if(Uz(NF,b)&&!a.d){switch(od(d)){case 40:qp(this,Aq(this.a.n)+1);a.c=true;td(a.f);return;case 38:qp(this,Aq(this.a.n)-1);a.c=true;td(a.f);return;case 34:g=this.a.n.c;(dr(),ar)==g?qp(this,Dq(this.a.n).a):cr==g&&qp(this,Aq(this.a.n)+30);a.c=true;td(a.f);return;case 33:h=this.a.n.c;(dr(),ar)==h?qp(this,-Dq(this.a.n).a):cr==h&&qp(this,Aq(this.a.n)-30);a.c=true;td(a.f);return;case 36:qp(this,-Dq(this.a.n).b);a.c=true;td(a.f);return;case 35:qp(this,zq(this.a.n).i-1);a.c=true;td(a.f);return;case 32:a.c=true;td(a.f);return;}}else if(Uz(iF,b)){e=a.a.a-Dq(this.a.n).b;f=a.f.target;c=(!Ip&&(Ip=new Sp),Jp(Ip,f));$o(this.a,e,!c)}else if(Uz(LF,b)){e=a.a.a-Dq(this.a.n).b;if(Aq(this.a.n)!=e){$o(this.a,e,false);return}}};an(131,1,{},Bp);_.b=false;an(132,1,{},Dp);_.D=function Ep(){var a;if(!aq(this.a.a)){a=Wp(this.a.a);!!a&&ad(a)}};an(133,73,{},Gp);an(134,1,{});var Ip;an(135,134,{});var Mp;an(136,135,{},Sp);an(137,125,OE,cq);_.S=function eq(){var b;try{this.f.V()}catch(a){a=sm(a);if(Wh(a,57)){b=a;throw new lt(cD(b))}else throw rm(a)}};_.T=function fq(){var b;try{this.f.X()}catch(a){a=sm(a);if(Wh(a,57)){b=a;throw new lt(cD(b))}else throw rm(a)}};_.b=false;var Up;an(138,1,{},hq);_.D=function iq(){Yo(this.a)};an(139,1,{},mq);var kq,lq;an(140,1,{},pq);_.a=false;an(144,1,{12:1,34:1},Nq);_._=function Oq(){return Dq(this)};_.ab=function Pq(a,b){Jq(this,a,b)};_.bb=function Qq(a,b){Kq(this,a,b)};_.b=false;_.g=0;an(145,1,{},Tq);_.D=function Uq(){this.a.f==this&&Fq(this.a,null)};an(146,1,{},Xq);_.d=0;_.e=null;_.f=0;_.g=0;_.i=0;_.j=false;_.o=null;_.p=false;an(147,146,{},Zq);_.a=false;_.b=false;an(148,48,{22:1,44:1,47:1,49:1},er);_.a=false;var _q,ar,br,cr;an(149,48,{23:1,44:1,47:1,49:1},mr);var hr,ir,jr,kr;an(150,62,{},rr);_.G=function sr(a){_h(a);null.Kb()};_.H=function tr(){return pr};var pr;an(151,1,{},vr);var wr,xr,yr;var Ar=null,Br,Cr;var Kr;var Or=false,Pr;an(158,62,{},Yr);_.G=function Zr(a){_h(a);null.Kb()};_.H=function $r(){return Wr};var Wr;an(159,76,IE,as);an(160,1,{});var cs=false;an(161,1,{},ls);an(164,160,{});var ps,qs,rs,ss;an(163,164,{});an(162,163,{},Hs);an(166,1,IE,Ps);_.db=function Qs(a){return decodeURI(a.replace(XF,WF))};_.eb=function Rs(a){return Ms(a)};_.fb=function Ss(a){a=a==null?cF:a;if(!Uz(a,Ks==null?cF:Ks)){Ks=a;of(this,a)}};var Ks=cF;an(171,127,QE);_.S=function Xs(){mt(this,(kt(),it))};_.T=function Ys(){mt(this,(kt(),jt))};an(170,171,QE);_.hb=function ct(){return new pv(this.b)};_.gb=function dt(a){return at(this,a)};an(169,170,QE);_.gb=function gt(a){var b;b=at(this,a);b&&ft((Dr(),a.u));return b};an(172,81,JE,lt);var it,jt;an(173,1,{},ot);_.ib=function pt(a){a.V()};an(174,1,{},rt);_.ib=function st(a){a.X()};an(177,127,ME);_.V=function xt(){var a;xo(this);a=wd((Dr(),this.u));-1==a&&kd(this.u,0)};an(176,177,ME);an(175,176,ME,At);an(178,170,QE,Ft);_.gb=function Gt(a){var b,c;b=(Dr(),rd(a.u));c=at(this,a);if(c){a.u.style[ZF]=cF;a.u.style[_F]=cF;so(a.u,true);Yc(this.u,b);this.a==a&&(this.a=null)}return c};var Ct;an(179,3,{},Kt);_.a=null;_.b=null;_.c=false;_.d=null;an(180,1,{},Nt);an(181,170,QE,Qt);an(182,127,ME,Ut);_.W=function Wt(a){var b,c,d,e,f,g,h,i;yo(this,a);if((Dr(),ds(a.type))==1&&(b=sd(a),c=!!a.altKey,d=!!a.ctrlKey,e=!!a.metaKey,f=!!a.shiftKey,g=c||d||e||f,h=b==4,i=b==2,!g&&!h&&!i)){Nr(this.c);td(a)}};an(184,169,RE);var du,eu,fu;an(185,1,{},nu);_.ib=function ou(a){a.U()&&a.X()};an(186,1,{8:1,11:1},qu);an(187,184,RE,su);an(188,171,QE,vu);_.hb=function xu(){return new Bu};_.gb=function yu(a){return uu(this,a)};an(189,1,{},Bu);_.jb=function Cu(){return false};_.kb=function Du(){return Au()};_.lb=function Eu(){};an(192,177,ME);_.W=function Ku(a){var b;b=(Dr(),ds(a.type));(b&896)!=0?yo(this,a):yo(this,a)};_.Y=function Lu(){};an(191,192,ME);an(190,191,ME);an(193,48,SE);var Pu,Qu,Ru,Su,Tu;an(194,193,SE,Yu);an(195,193,SE,$u);an(196,193,SE,av);an(197,193,SE,cv);an(198,1,{},kv);_.hb=function lv(){return new pv(this)};_.c=0;an(199,1,{},pv);_.jb=function qv(){return this.b<this.c.c};_.kb=function rv(){return nv(this)};_.lb=function sv(){ov(this)};_.b=0;an(203,1,{});_.c=-1;_.d=false;an(204,1,{11:1,36:1},Av);an(205,62,{},Dv);_.G=function Ev(a){Uh(a,33).cb(this)};_.H=function Gv(){return Cv};_.c=false;_.d=false;_.e=false;var Cv;an(206,1,PE,Iv);_.cb=function Jv(a){var b;if(a.d||a.e){return}b=a.b;b.n;return};an(207,203,{},Mv);an(208,1,TE,Vv,Wv);_.mb=function Xv(a){return Pv(this,a)};_.nb=function Yv(){Qv(this)};_.ob=function Zv(a){return this.f.ob(a)};_.eQ=function $v(a){return this.f.eQ(a)};_.pb=function _v(a){return Tv(this,a)};_.hC=function aw(){return this.f.hC()};_.qb=function bw(a){return this.f.qb(a)};_.rb=function cw(){return this.f.rb()};_.hb=function dw(){return new qw(this)};_.sb=function ew(){return new qw(this)};_.tb=function fw(a){return new rw(this,a)};_.ub=function gw(a){return Uv(this,a)};_.vb=function hw(a){var b;b=this.f.qb(a);if(b==-1){return false}Uv(this,b);return true};_.wb=function iw(){return this.f.wb()};_.xb=function jw(a,b){return new Wv(this.n,this.f.xb(a,b),this,a)};_.yb=function kw(){return this.f.yb()};_.a=0;_.c=false;_.e=false;_.g=-2147483648;_.i=2147483647;_.j=false;_.k=0;an(209,1,{},mw);_.D=function nw(){this.a.e=false;if(this.a.c){this.a.c=false;return}Sv(this.a)};an(210,1,{},qw,rw);_.jb=function sw(){return this.a<this.c.f.wb()};_.zb=function tw(){return this.a>0};_.kb=function uw(){if(this.a>=this.c.f.wb()){throw new zE}return Tv(this.c,this.b=this.a++)};_.Ab=function vw(){if(this.a<=0){throw new zE}return Tv(this.c,this.b=--this.a)};_.lb=function ww(){if(this.b<0){throw new rz('Cannot call add/remove more than once per call to next/previous.')}Uv(this.c,this.b);this.a=this.b;this.b=-1};_.a=0;_.b=-1;an(211,1,{35:1,44:1},yw);_.eQ=function zw(a){var b;if(!Wh(a,35)){return false}b=Uh(a,35);return this.b==b.b&&this.a==b.a};_.hC=function Aw(){return this.a*31^this.b};_.tS=function Bw(){return 'Range('+this.b+qF+this.a+wF};_.a=0;_.b=0;an(212,62,{},Fw);_.G=function Gw(a){Ew(Uh(a,36))};_.H=function Iw(){return Dw};var Dw;an(213,1,{},Lw);an(214,1,UE,Nw);_.D=function Ow(){Bf(this.a,this.c,this.b)};an(215,1,UE,Qw);_.D=function Rw(){Df(this.a,this.c,this.b)};an(217,190,ME,Tw);an(218,7,{},ax);_.a=false;an(220,1,{39:1},gx,hx);_.a=false;an(221,1,{},tx);an(222,1,{},wx);an(223,1,{11:1,43:1},yx);an(224,1,{11:1,42:1},Ax);an(225,1,{10:1,11:1},Cx);an(226,48,{40:1,44:1,47:1,49:1},Jx);var Ex,Fx,Gx,Hx;an(227,1,{},Mx);_.Bb=function Nx(a){return !a.a};an(228,1,{},Px);_.Bb=function Qx(a){return true};an(229,1,{},Sx);_.Bb=function Tx(a){return a.a};an(230,126,NE,_x);an(231,1,{24:1},by);_.W=function cy(a){vx(this.b,!!this.a.o.checked)};an(232,1,KE,ey);_.J=function fy(a){od(a.a)==13&&jx(this.a.a)};an(233,1,{5:1,11:1,41:1},hy);an(234,1,{},ky);an(235,1,{},ny);var my;an(236,1,{},qy);_.a=false;an(239,62,{});var vy;an(240,239,{},Cy);_.G=function Dy(a){By(this,Uh(a,42))};_.H=function Ey(){return zy};var zy;an(241,239,{},Jy);_.G=function Ky(a){Iy(this,Uh(a,43))};_.H=function Ly(){return Gy};var Gy;an(242,12,GE,Ny);an(243,12,GE,Py);an(244,1,{44:1,45:1,47:1},Sy);_.eQ=function Ty(a){return Wh(a,45)&&Uh(a,45).a==this.a};_.hC=function Uy(){return this.a?1231:1237};_.tS=function Vy(){return this.a?JF:'false'};_.a=false;an(246,1,{},Yy);_.tS=function dz(){return ((this.a&2)!=0?'interface ':(this.a&1)!=0?cF:'class ')+this.c};_.a=0;_.b=0;an(247,12,GE,fz);an(249,1,{44:1,54:1});an(248,249,{44:1,47:1,48:1,54:1},jz);_.eQ=function kz(a){return Wh(a,48)&&Uh(a,48).a==this.a};_.hC=function lz(){return $h(this.a)};_.tS=function mz(){return cF+this.a};_.a=0;an(250,12,GE,oz);an(251,12,GE,qz,rz);an(252,12,{44:1,51:1,52:1,55:1,57:1},tz,uz);an(253,249,{44:1,47:1,53:1,54:1},wz);_.eQ=function xz(a){return Wh(a,53)&&Uh(a,53).a==this.a};_.hC=function yz(){return this.a};_.tS=function Cz(){return cF+this.a};_.a=0;var Ez;an(256,12,GE,Jz,Kz);var Lz;an(258,250,GE,Oz);an(259,1,{44:1,56:1},Qz);_.tS=function Rz(){return this.a+'.'+this.c+'(Unknown Source'+(this.b>=0?gF+this.b:cF)+wF};_.b=0;_=String.prototype;_.cM={1:1,44:1,46:1,47:1};_.eQ=function _z(a){return Uz(this,a)};_.hC=function aA(){return gA(this)};_.tS=_.toString;var bA,cA=0,dA;an(261,1,VE,lA);_.tS=function mA(){return this.a.a};an(262,1,VE,qA,rA);_.tS=function sA(){return this.a.a};an(263,12,{44:1,51:1,55:1,57:1,58:1},uA,vA);an(264,1,{});_.mb=function zA(a){throw new vA('Add not supported on this collection')};_.Cb=function AA(a){var b,c;c=a.hb();b=false;while(c.jb()){this.mb(c.kb())&&(b=true)}return b};_.ob=function BA(a){var b;b=xA(this.hb(),a);return !!b};_.rb=function CA(){return this.wb()==0};_.vb=function DA(a){var b;b=xA(this.hb(),a);if(b){b.lb();return true}else{return false}};_.yb=function EA(){return this.Db(Kh(mm,FE,0,this.wb(),0))};_.Db=function FA(a){var b,c,d;d=this.wb();a.length<d&&(a=Ih(a,d));c=this.hb();for(b=0;b<d;++b){Mh(a,b,c.kb())}a.length>d&&Mh(a,d,null);return a};_.tS=function GA(){return yA(this)};an(266,1,WE);_.eQ=function KA(a){var b,c,d,e,f;if(a===this){return true}if(!Wh(a,61)){return false}e=Uh(a,61);if(this.d!=e.d){return false}for(c=new qB((new iB(e)).a);YB(c.a);){b=c.b=Uh(ZB(c.a),62);d=b.Fb();f=b.Gb();if(!(d==null?this.c:Wh(d,1)?VA(this,Uh(d,1)):UA(this,d,~~Jb(d)))){return false}if(!AE(f,d==null?this.b:Wh(d,1)?TA(this,Uh(d,1)):SA(this,d,~~Jb(d)))){return false}}return true};_.hC=function LA(){var a,b,c;c=0;for(b=new qB((new iB(this)).a);YB(b.a);){a=b.b=Uh(ZB(b.a),62);c+=a.hC();c=~~c}return c};_.tS=function MA(){var a,b,c,d;d=sF;a=false;for(c=new qB((new iB(this)).a);YB(c.a);){b=c.b=Uh(ZB(c.a),62);a?(d+=tF):(a=true);d+=cF+b.Fb();d+=pG;d+=cF+b.Gb()}return d+uF};an(265,266,WE);_.Eb=function cB(a,b){return Zh(a)===Zh(b)||a!=null&&Ib(a,b)};_.c=false;_.d=0;an(268,264,XE);_.eQ=function fB(a){var b,c,d;if(a===this){return true}if(!Wh(a,63)){return false}c=Uh(a,63);if(c.wb()!=this.wb()){return false}for(b=c.hb();b.jb();){d=b.kb();if(!this.ob(d)){return false}}return true};_.hC=function gB(){var a,b,c;a=0;for(b=this.hb();b.jb();){c=b.kb();if(c!=null){a+=Jb(c);a=~~a}}return a};an(267,268,XE,iB);_.ob=function jB(a){return hB(this,a)};_.hb=function kB(){return new qB(this.a)};_.vb=function lB(a){var b;if(hB(this,a)){b=Uh(a,62).Fb();$A(this.a,b);return true}return false};_.wb=function mB(){return this.a.d};an(269,1,{},qB);_.jb=function rB(){return YB(this.a)};_.kb=function sB(){return oB(this)};_.lb=function tB(){pB(this)};_.b=null;an(271,1,YE);
_.eQ=function wB(a){var b;if(Wh(a,62)){b=Uh(a,62);if(AE(this.Fb(),b.Fb())&&AE(this.Gb(),b.Gb())){return true}}return false};_.hC=function xB(){var a,b;a=0;b=0;this.Fb()!=null&&(a=Jb(this.Fb()));this.Gb()!=null&&(b=Jb(this.Gb()));return a^b};_.tS=function yB(){return this.Fb()+pG+this.Gb()};an(270,271,YE,zB);_.Fb=function AB(){return null};_.Gb=function BB(){return this.a.b};_.Hb=function CB(a){return YA(this.a,a)};an(272,271,YE,EB);_.Fb=function FB(){return this.a};_.Gb=function GB(){return TA(this.b,this.a)};_.Hb=function HB(a){return ZA(this.b,this.a,a)};an(273,264,TE);_.Ib=function JB(a,b){throw new vA('Add not supported on this list')};_.mb=function KB(a){this.Ib(this.wb(),a);return true};_.nb=function MB(){this.Jb(0,this.wb())};_.eQ=function NB(a){var b,c,d,e,f;if(a===this){return true}if(!Wh(a,60)){return false}f=Uh(a,60);if(this.wb()!=f.wb()){return false}d=new _B(this);e=f.hb();while(d.b<d.d.wb()){b=ZB(d);c=e.kb();if(!(b==null?c==null:Ib(b,c))){return false}}return true};_.hC=function OB(){var a,b,c;b=1;a=new _B(this);while(a.b<a.d.wb()){c=ZB(a);b=31*b+(c==null?0:Jb(c));b=~~b}return b};_.qb=function PB(a){var b,c;for(b=0,c=this.wb();b<c;++b){if(a==null?this.pb(b)==null:Ib(a,this.pb(b))){return b}}return -1};_.hb=function RB(){return new _B(this)};_.sb=function SB(){return new eC(this,0)};_.tb=function TB(a){return new eC(this,a)};_.ub=function UB(a){throw new vA('Remove not supported on this list')};_.Jb=function VB(a,b){var c,d;d=new eC(this,a);for(c=a;c<b;++c){ZB(d);$B(d)}};_.xb=function WB(a,b){return new iC(this,a,b)};an(274,1,{},_B);_.jb=function aC(){return YB(this)};_.kb=function bC(){return ZB(this)};_.lb=function cC(){$B(this)};_.b=0;_.c=-1;an(275,274,{},eC);_.zb=function fC(){return this.b>0};_.Ab=function gC(){if(this.b<=0){throw new zE}return this.a.pb(this.c=--this.b)};an(276,273,TE,iC);_.Ib=function jC(a,b){LB(a,this.b+1);++this.b;this.c.Ib(this.a+a,b)};_.pb=function kC(a){LB(a,this.b);return this.c.pb(this.a+a)};_.ub=function lC(a){var b;LB(a,this.b);b=this.c.ub(this.a+a);--this.b;return b};_.wb=function mC(){return this.b};_.a=0;_.b=0;an(277,268,XE,pC);_.ob=function qC(a){return QA(this.a,a)};_.hb=function rC(){return oC(this)};_.wb=function sC(){return this.b.a.d};an(278,1,{},vC);_.jb=function wC(){return YB(this.a.a)};_.kb=function xC(){return uC(this)};_.lb=function yC(){pB(this.a)};an(279,273,ZE,KC);_.Ib=function LC(a,b){AC(this,a,b)};_.mb=function MC(a){return BC(this,a)};_.Cb=function NC(a){return CC(this,a)};_.nb=function OC(){DC(this)};_.ob=function PC(a){return FC(this,a,0)!=-1};_.pb=function QC(a){return EC(this,a)};_.qb=function RC(a){return FC(this,a,0)};_.rb=function SC(){return this.b==0};_.ub=function TC(a){return GC(this,a)};_.vb=function UC(a){return HC(this,a)};_.Jb=function VC(a,b){var c;LB(a,this.b+1);(b<a||b>this.b)&&QB(b,this.b);c=b-a;XC(this.a,a,c);this.b-=c};_.wb=function WC(){return this.b};_.yb=function $C(){return Hh(this.a,this.b)};_.Db=function _C(a){return JC(this,a)};_.b=0;var aD;an(281,273,ZE,fD);_.ob=function gD(a){return false};_.pb=function hD(a){throw new tz};_.wb=function iD(){return 0};an(282,1,{});_.mb=function mD(a){throw new uA};_.Cb=function nD(a){throw new uA};_.nb=function oD(){throw new uA};_.ob=function pD(a){return kD(this,a)};_.hb=function qD(){return new wD(this.b.hb())};_.vb=function rD(a){throw new uA};_.wb=function sD(){return this.b.wb()};_.yb=function tD(){return this.b.yb()};_.tS=function uD(){return this.b.tS()};an(283,1,{},wD);_.jb=function xD(){return this.b.jb()};_.kb=function yD(){return this.b.kb()};_.lb=function zD(){throw new uA};an(284,282,TE,BD);_.eQ=function CD(a){return this.a.eQ(a)};_.pb=function DD(a){return this.a.pb(a)};_.hC=function ED(){return this.a.hC()};_.qb=function FD(a){return this.a.qb(a)};_.rb=function GD(){return this.a.rb()};_.sb=function HD(){return new MD(this.a.tb(0))};_.tb=function ID(a){return new MD(this.a.tb(a))};_.ub=function JD(a){throw new uA};_.xb=function KD(a,b){return new BD(this.a.xb(a,b))};an(285,283,{},MD);_.zb=function ND(){return this.a.zb()};_.Ab=function OD(){return this.a.Ab()};an(286,284,TE,QD);an(287,282,XE,SD);_.eQ=function TD(a){return this.b.eQ(a)};_.hC=function UD(){return this.b.hC()};an(288,1,{44:1,47:1,59:1},WD);_.eQ=function XD(a){return Wh(a,59)&&Km(Lm(this.a.getTime()),Lm(Uh(a,59).a.getTime()))};_.hC=function YD(){var a;a=Lm(this.a.getTime());return Sm(Um(a,Qm(a,32)))};_.tS=function $D(){var a,b,c;c=-this.a.getTimezoneOffset();a=(c>=0?'+':cF)+~~(c/60);b=(c<0?-c:c)%60<10?yF+(c<0?-c:c)%60:cF+(c<0?-c:c)%60;return (bE(),_D)[this.a.getDay()]+hF+aE[this.a.getMonth()]+hF+ZD(this.a.getDate())+hF+ZD(this.a.getHours())+gF+ZD(this.a.getMinutes())+gF+ZD(this.a.getSeconds())+' GMT'+a+b+hF+this.a.getFullYear()};var _D,aE;an(290,265,{44:1,61:1},eE,fE);an(291,268,{44:1,63:1},kE,lE);_.mb=function mE(a){return hE(this,a)};_.ob=function nE(a){return iE(this,a)};_.rb=function oE(){return this.a.d==0};_.hb=function pE(){return oC(JA(this.a))};_.vb=function qE(a){return jE(this,a)};_.wb=function rE(){return this.a.d};_.tS=function sE(){return yA(JA(this.a))};an(292,271,YE,uE);_.Fb=function vE(){return this.a};_.Gb=function wE(){return this.b};_.Hb=function xE(a){var b;b=this.b;this.b=a;return b};an(293,12,GE,zE);var $E=fc();var tl=$y(rG,'Object',1),ji=$y(sG,'Scheduler',21),ii=$y(sG,'JavaScriptObject$',15),cm=Zy(cF,'[I',300),mm=Zy(tG,'Object;',298),zl=$y(rG,'Throwable',14),ll=$y(rG,'Exception',13),ul=$y(rG,'RuntimeException',12),vl=$y(rG,'StackTraceElement',259),nm=Zy(tG,'StackTraceElement;',301),fm=Zy('[Lcom.google.gwt.lang.','LongLibBase$LongEmul;',302),Zi=$y('com.google.gwt.lang.','SeedUtil',104),kl=$y(rG,'Enum',48),gl=$y(rG,'Boolean',244),sl=$y(rG,'Number',249),bm=Zy(cF,'[C',303),il=$y(rG,'Class',246),jl=$y(rG,'Double',248),pl=$y(rG,'Integer',253),lm=Zy(tG,'Integer;',304),yl=$y(rG,bF,2),om=Zy(tG,'String;',299),hl=$y(rG,'ClassCastException',247),hi=$y(sG,'JavaScriptException',11),xl=$y(rG,'StringBuilder',262),fl=$y(rG,'ArrayStoreException',243),ik=$y(uG,'UIObject',128),rk=$y(uG,'Widget',127),Uj=$y(uG,'Composite',126),al=$y(vG,'ToDoView',230),Wk=$y(vG,'ToDoView$1',231),Xk=$y(vG,'ToDoView$2',232),Yk=$y(vG,'ToDoView$3',233),Rk=$y(vG,'ToDoPresenter',221),Nk=$y(vG,'ToDoPresenter$1',222),Ok=$y(vG,'ToDoPresenter$2',223),Pk=$y(vG,'ToDoPresenter$3',224),Qk=$y(vG,'ToDoPresenter$4',225),Ek=$y(wG,'Event',63),Ji=$y(xG,'GwtEvent',62),bl=$y(yG,'ToDoEvent',239),dl=$y(yG,'ToDoUpdatedEvent',241),Ck=$y(wG,'Event$Type',66),Ii=$y(xG,'GwtEvent$Type',65),cl=$y(yG,'ToDoRemovedEvent',240),_j=$y(uG,'Panel',171),Tj=$y(uG,'ComplexPanel',170),Nj=$y(uG,'AbsolutePanel',169),Jk=$y(wG,zG,82),Oi=$y(xG,zG,81),Qj=$y(uG,'AttachDetachException',172),Oj=$y(uG,'AttachDetachException$1',173),Pj=$y(uG,'AttachDetachException$2',174),dk=$y(uG,'RootPanel',184),ck=$y(uG,'RootPanel$DefaultRootPanel',187),ak=$y(uG,'RootPanel$1',185),bk=$y(uG,'RootPanel$3',186),ql=$y(rG,'NullPointerException',256),ml=$y(rG,'IllegalArgumentException',250),el=$y(rG,'ArithmeticException',242),pi=$y(AG,'StringBufferImpl',29),pj=$y(BG,'AbstractHasData',125),lj=$y(BG,'AbstractHasData$DefaultKeyboardSelectionHandler',130),oj=$y(BG,'AbstractHasData$View',131),mj=$y(BG,'AbstractHasData$View$1',132),Gi=$y(CG,'ValueChangeEvent',73),nj=$y(BG,'AbstractHasData$View$2',133),kj=$y(BG,'AbstractHasData$1',129),Bj=_y(BG,'HasKeyboardPagingPolicy$KeyboardPagingPolicy',148,fr),gm=Zy(DG,'HasKeyboardPagingPolicy$KeyboardPagingPolicy;',305),Cj=_y(BG,'HasKeyboardSelectionPolicy$KeyboardSelectionPolicy',149,nr),hm=Zy(DG,'HasKeyboardSelectionPolicy$KeyboardSelectionPolicy;',306),uk=$y(EG,'CellPreviewEvent',205),Aj=$y(BG,'HasDataPresenter',144),yj=$y(BG,'HasDataPresenter$DefaultState',146),zj=$y(BG,'HasDataPresenter$PendingState',147),xj=$y(BG,'HasDataPresenter$2',145),wj=$y(BG,'CellList',137),tj=$y(BG,'CellList$1',138),Yj=$y(uG,'FocusWidget',177),Rj=$y(uG,'ButtonBase',176),Sj=$y(uG,'Button',175),ok=$y(uG,'ValueBoxBase',192),gk=$y(uG,'TextBoxBase',191),hk=$y(uG,'TextBox',190),Kk=$y(vG,'TextBoxWithPlaceholder',217),nk=_y(uG,'ValueBoxBase$TextAlignment',193,Wu),im=Zy(FG,'ValueBoxBase$TextAlignment;',307),jk=_y(uG,'ValueBoxBase$TextAlignment$1',194,null),kk=_y(uG,'ValueBoxBase$TextAlignment$2',195,null),lk=_y(uG,'ValueBoxBase$TextAlignment$3',196,null),mk=_y(uG,'ValueBoxBase$TextAlignment$4',197,null),Pi=$y(GG,'AutoDirectionHandler',83),Qi=_y(GG,'HasDirection$Direction',85,ig),em=Zy('[Lcom.google.gwt.i18n.client.','HasDirection$Direction;',308),Fj=$y(HG,'Window$ClosingEvent',158),Li=$y(xG,'HandlerManager',76),Gj=$y(HG,'Window$WindowHandlers',159),Dk=$y(wG,IG,75),Ik=$y(wG,JG,78),Ki=$y(xG,'HandlerManager$Bus',77),Fk=$y(wG,'SimpleEventBus$1',213),Gk=$y(wG,'SimpleEventBus$2',214),Hk=$y(wG,'SimpleEventBus$3',215),Vk=_y(vG,'ToDoRouting',226,Kx),km=Zy('[Lcom.todo.client.','ToDoRouting;',309),Tk=$y(vG,'ToDoRouting$MatchAll',228),Sk=$y(vG,'ToDoRouting$MatchActive',227),Uk=$y(vG,'ToDoRouting$MatchCompleted',229),tk=$y(EG,'AbstractDataProvider',203),zk=$y(EG,'ListDataProvider',207),yk=$y(EG,'ListDataProvider$ListWrapper',208),xk=$y(EG,'ListDataProvider$ListWrapper$WrappedListIterator',210),wk=$y(EG,'ListDataProvider$ListWrapper$1',209),sk=$y(EG,'AbstractDataProvider$1',204),Ak=$y(EG,'RangeChangeEvent',212),Hi=$y(xG,IG,74),Ol=$y(KG,'AbstractMap',266),Gl=$y(KG,'AbstractHashMap',265),Zl=$y(KG,'HashMap',290),Bl=$y(KG,'AbstractCollection',264),Pl=$y(KG,'AbstractSet',268),Dl=$y(KG,'AbstractHashMap$EntrySet',267),Cl=$y(KG,'AbstractHashMap$EntrySetIterator',269),Nl=$y(KG,'AbstractMapEntry',271),El=$y(KG,'AbstractHashMap$MapEntryNull',270),Fl=$y(KG,'AbstractHashMap$MapEntryString',272),Ml=$y(KG,'AbstractMap$1',277),Ll=$y(KG,'AbstractMap$1$1',278),$l=$y(KG,'HashSet',291),ni=$y(AG,'StackTraceCreator$Collector',28),oi=$y(AG,'StringBufferImplAppend',30),gi=$y(sG,'Duration',9),mi=$y(AG,'SchedulerImpl',23),ki=$y(AG,'SchedulerImpl$Flusher',24),li=$y(AG,'SchedulerImpl$Rescuer',25),ei=$y(LG,'AbstractCell',7),Lk=$y(vG,'ToDoCell',218),fi=$y(LG,'Cell$Context',8),Zk=$y(vG,'ToDoView_ToDoViewUiBinderImpl$Widgets',234),nl=$y(rG,'IllegalStateException',251),Kl=$y(KG,'AbstractList',273),Ql=$y(KG,'ArrayList',279),Hl=$y(KG,'AbstractList$IteratorImpl',274),Il=$y(KG,'AbstractList$ListIteratorImpl',275),Jl=$y(KG,'AbstractList$SubList',276),ej=$y(MG,'Storage',115),dj=$y(MG,'Storage$StorageSupportDetector',116),Yi=$y(NG,'JSONValue',87),Ri=$y(NG,'JSONArray',86),Wi=$y(NG,'JSONObject',92),Xi=$y(NG,'JSONString',94),Si=$y(NG,'JSONBoolean',88),Mk=$y(vG,'ToDoItem',220),Mj=$y(OG,'HistoryImpl',166),$j=$y(uG,'Hyperlink',182),Ni=$y(xG,JG,80),qk=$y(uG,'WidgetCollection',198),jm=Zy(FG,'Widget;',310),pk=$y(uG,'WidgetCollection$WidgetIterator',199),Lj=$y(OG,'DOMImpl',160),Hj=$y(OG,'DOMImpl$1',161),Kj=$y(OG,'DOMImplStandard',164),Jj=$y(OG,'DOMImplStandardBase',163),Ij=$y(OG,'DOMImplIE9',162),yi=$y(PG,'DomEvent',61),Bi=$y(PG,'KeyEvent',68),Ai=$y(PG,'KeyCodeEvent',67),Ci=$y(PG,'KeyUpEvent',69),xi=$y(PG,'DomEvent$Type',64),zi=$y(PG,'HumanInputEvent',60),Di=$y(PG,'MouseEvent',59),wi=$y(PG,'ClickEvent',58),Al=$y(rG,'UnsupportedOperationException',263),wl=$y(rG,'StringBuffer',261),vj=$y(BG,'CellList_Resources_default_InlineClientBundleGenerator',139),uj=$y(BG,'CellList_Resources_default_InlineClientBundleGenerator$1',140),Wj=$y(uG,'DeckPanel',178),di=$y(QG,'Animation',3),Vj=$y(uG,'DeckPanel$SlideAnimation',179),ci=$y(QG,'AnimationScheduler',4),fk=$y(uG,'SimplePanel',188),ek=$y(uG,'SimplePanel$1',189),sj=$y(BG,'CellBasedWidgetImpl',134),Ti=$y(NG,'JSONException',89),ui=_y(RG,'Style$Display',47,Qd),dm=Zy('[Lcom.google.gwt.dom.client.','Style$Display;',311),qi=_y(RG,'Style$Display$1',49,null),ri=_y(RG,'Style$Display$2',50,null),si=_y(RG,'Style$Display$3',51,null),ti=_y(RG,'Style$Display$4',52,null),_l=$y(KG,'MapEntryImpl',292),Fi=$y(CG,'CloseEvent',72),ol=$y(rG,'IndexOutOfBoundsException',252),Rl=$y(KG,'Collections$EmptyList',281),Tl=$y(KG,'Collections$UnmodifiableCollection',282),Vl=$y(KG,'Collections$UnmodifiableList',284),Wl=$y(KG,'Collections$UnmodifiableRandomAccessList',286),Xl=$y(KG,'Collections$UnmodifiableSet',287),Sl=$y(KG,'Collections$UnmodifiableCollectionIterator',283),Ul=$y(KG,'Collections$UnmodifiableListIterator',285),rj=$y(BG,'CellBasedWidgetImplStandard',135),qj=$y(BG,'CellBasedWidgetImplStandardBase',136),Zj=$y(uG,'HTMLPanel',181),Vi=$y(NG,'JSONNumber',91),Ui=$y(NG,'JSONNull',90),Ei=$y(PG,'PrivateMap',70),Mi=$y(xG,'LegacyHandlerWrapper',79),Bk=$y(EG,'Range',211),am=$y(KG,'NoSuchElementException',293),vk=$y(EG,'DefaultSelectionEventManager',206),bj=$y(SG,'SafeHtmlString',111),ij=$y(TG,'LazyDomElement',122),jj=$y(TG,'UiBinderUtil$TempAttachment',124),_k=$y(vG,'ToDoView_ToDoViewUiBinderImpl_GenBundle_default_InlineClientBundleGenerator',235),$k=$y(vG,'ToDoView_ToDoViewUiBinderImpl_GenBundle_default_InlineClientBundleGenerator$1',236),_i=$y(SG,'OnlyToBeUsedInGeneratedCodeStringBlessedAsSafeHtml',109),aj=$y(SG,'SafeHtmlBuilder',110),vi=$y(RG,'StyleInjector$1',55),Xj=$y(uG,'DirectionalTextHelper',180),Ej=$y(BG,'LoadingStateChangeEvent',150),Dj=$y(BG,'LoadingStateChangeEvent$DefaultLoadingState',151),rl=$y(rG,'NumberFormatException',258),$i=$y('com.google.gwt.resources.client.impl.','ImageResourcePrototype',108),fj=$y('com.google.gwt.text.shared.','AbstractRenderer',119),hj=$y(UG,'PassthroughRenderer',121),gj=$y(UG,'PassthroughParser',120),cj=$y(SG,'SafeUriString',113),Yl=$y(KG,'Date',288),bi=$y(QG,'AnimationSchedulerImpl',5),ai=$y(QG,'AnimationSchedulerImplTimer',6);$stats && $stats({moduleName:'gwttodo',sessionId:$sessionId,subSystem:'startup',evtGroup:'moduleStartup',millis:(new Date()).getTime(),type:'moduleEvalEnd'});if (gwttodo && gwttodo.onScriptLoad)gwttodo.onScriptLoad(gwtOnLoad);})();